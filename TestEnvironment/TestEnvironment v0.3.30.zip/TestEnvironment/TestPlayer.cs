using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Terraria;
using Terraria.Localization;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;

namespace TestEnvironment
{
    public class TestPlayer : ModPlayer
    {
        public bool magnoMinion;
        public bool magnoShield;
        public bool magnoRanged;
        public bool MagnoZone;
        public bool magnoInvuln;
        bool flag;
        public int[] MPID = new int[255];
        int num;
        int ticks = 1;
        int debuffTime = 300;
        const int hellLayer = 192;
        const int tileSize = 16;
        public override void PostUpdate()
        {
            TestWorld modWorld = mod.GetModWorld<TestWorld>();

            #region item checks
            for (int k = 0; k < player.armor.Length; k++)
            {
                if (player.armor[k].type == mod.ItemType<Items.magno_shieldacc>())
                {
                    magnoShield = true;
                    break;
                }
                else magnoShield = false;
            }
            for (int k = 0; k < player.armor.Length; k++)
            {
                if (player.armor[k].type == mod.ItemType<Items.Armors.magnoheadgear>())
                {
                    magnoRanged = true;
                    break;
                }
                else
                {
                    magnoRanged = false;
                }

            }
            #endregion

            if (MagnoZone && !modWorld.MagnoDefeated)
            {
                if(!player.HasBuff(mod.BuffType<Buffs.magno_uncursed>()))
                {
                    player.AddBuff(BuffID.WaterCandle, debuffTime, true);
                }
            }

            if (!modWorld.MagnoDefeated)
            {
                if (player.position.Y > (Main.maxTilesY * tileSize) - hellLayer * tileSize) 
                {
                    player.AddBuff(BuffID.OnFire, debuffTime, false);
                    if (!flag)
                    {
                        Main.NewText("Energy from the red crystals gathers here", 210, 110, 110);
                        flag = true;
                    }
                }
            }

        /*  if (Main.netMode == 0)
            {
                player.statLife = player.statLifeMax;
                if (Main.mouseMiddle)
                {   
                        Main.dayTime = true;
                        Main.time = 12400;
                    //  Main.NewText("Location: i, " + Math.Round(player.position.X / 16, 0) + " j, " + Math.Round(player.position.Y / 16, 0), Color.White);
                    //  Main.dayTime = false;
                    //  Main.time = 12400;
                }
            }   */
            if (ticks == 0)
            {
                int item = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), mod.ItemType<Items.Armors.magnoheadgear>(), 1, true, -1, true, false);
                int item2 = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), mod.ItemType<Items.Armors.magnoplate>(), 1, true, -1, true, false);
                int item3 = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), mod.ItemType<Items.Armors.magnogreaves>(), 1, true, -1, true, false);
                //  int item = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), mod.ItemType<Items.magno_summonstaff>(), 1, true, -1, true, false);
                /*  int head = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.SilverHelmet, 1, true, -1, true, false);
                    int body = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.SilverChainmail, 1, true, -1, true, false);
                    int legs = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.SilverGreaves, 1, true, -1, true, false);
                    int weapon = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.GoldBow, 1, true, -1, true, false);
                    int pickaxe = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.SilverPickaxe, 1, true, -1, true, false);
                    int axe = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.SilverAxe, 1, true, -1, true, false);
                    int hammer = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.SilverHammer, 1, true, -1, true, false);
                    int ammoArrows = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.JestersArrow, 999, true, -1, true, false);
                    int ammoBullets = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.MusketBall, 999, true, -1, true, false);
                    int acc = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.CloudinaBottle, 1, true, -1, true, false);
                    int acc2 = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.ShoeSpikes, 1, true, -1, true, false);
                    int acc3 = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.MagicMirror, 1, true, -1, true, false);
                    int dummy = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.TargetDummy, 1, true, -1, true, false);
                    int dpsMeter = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.DPSMeter, 1, true, -1, true, false); 
                    int ammoArrows2 = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.WoodenArrow, 1998, true, -1, true, false);
                    int ammoArrows3 = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.JestersArrow, 999, true, -1, true, false);
                    int voodooDolls = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.GuideVoodooDoll, 3, true, -1, true, false);
                    int acc5 = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.LavaCharm, 1, true, -1, true, false);
                    int bridgeBlocks = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.IceBlock, 2997, true, -1, true, false);
                    int lifeCrystals = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.LifeCrystal, 15, true, -1, true, false);
                    int mount = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.FuzzyCarrot, 1, true, -1, true, false);    */
                ticks = 1;
            }
        }

        public override void SyncPlayer(int toWho, int fromWho, bool newPlayer)
        {
            ModPacket packet = mod.GetPacket();
            packet.Write((byte)player.whoAmI);
            packet.Send(toWho, fromWho);
        }

        public override void UpdateBiomes()
        {
            MagnoZone = (TestWorld.magnoTiles >= 100);
        }
        public override bool CustomBiomesMatch(Player other)
        {
            TestPlayer modOther = other.GetModPlayer<TestPlayer>(mod);
            return MagnoZone == modOther.MagnoZone;
        }
        public override void CopyCustomBiomesTo(Player other)
        {
            TestPlayer modOther = other.GetModPlayer<TestPlayer>(mod);
            modOther.MagnoZone = MagnoZone;
        }
        public override void SendCustomBiomes(BinaryWriter writer)
        {
            BitsByte flags = new BitsByte();
            flags[0] = MagnoZone;
            writer.Write(flags);
        }
        public override void ReceiveCustomBiomes(BinaryReader reader)
        {
            BitsByte flags = reader.ReadByte();
            MagnoZone = flags[0];
        }
        public override Texture2D GetMapBackgroundImage()
        {
            if (MagnoZone)
            {
                return mod.GetTexture("Backgrounds/MapBGMagno");
            }
            return null;
        }
    }
}