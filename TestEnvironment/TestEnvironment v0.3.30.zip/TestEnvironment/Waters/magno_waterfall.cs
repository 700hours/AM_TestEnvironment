﻿using Terraria;
using Terraria.ModLoader;

namespace TestEnvironment.Waters
{
    public class magno_waterfall : ModWaterfallStyle
    {

    }
}
