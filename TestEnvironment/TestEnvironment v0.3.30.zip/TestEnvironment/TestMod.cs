using System;
using Microsoft.Xna.Framework;

using Terraria;
using Terraria.Graphics.Effects;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment
{
	public class TestMod : Mod
	{
        public const string magnoHead = "TestEnvironment/Gores/magno_icon";
        public void SetModInfo(out string name, ref ModProperties properties)
		{
			name = "The Archaea Mod";
			properties.Autoload = true;
			properties.AutoloadGores = true;
			properties.AutoloadSounds = true;
		}
        public override void Load()
        {
            AddBossHeadTexture(magnoHead);
        }
    }
}
