﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment.Projectiles
{
    public class magno_flame : ModProjectile
    {
        public override void SetDefaults()
        {
            projectile.width = 16;
            projectile.height = 16;
            projectile.scale = 1f;
            projectile.aiStyle = -1;
            projectile.timeLeft = 300;
            projectile.friendly = false;
            projectile.penetrate = 1;
            projectile.tileCollide = false;
            projectile.ignoreWater = true;
            projectile.ranged = true;
        }

        int ticks;
        public override void AI()
        {
            ticks++;

            projectile.rotation = MathHelper.ToRadians(ticks * 9);

            if (ticks % 3 == 0)
            {
                for (int i = 0; i < 2; i++)
                {
                    int Dust1 = Dust.NewDust(projectile.position, 16, 16, 73, 0f, 0f, 0, Color.White, 1.2f);
                }
            }
        }
        public override void Kill(int timeLeft)
        {
            for(int i = 0; i < 3; i++)
            {
                int Dust1 = Dust.NewDust(projectile.position, 16, 16, 73, projectile.velocity.X, projectile.velocity.Y, 0, Color.White, 1.2f);
            }
        }
    }
}
