﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment.Items
{
    public class cinnabar_sword : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Cinnabar Sword");
            Tooltip.SetDefault("25% chance to throw");
        }
        public override void SetDefaults()
        {
            item.width = 44;
            item.height = 44;
            item.scale = 1f;
            item.useTime = 18;
            item.useAnimation = 18;
            item.useStyle = 1;
            item.damage = 20;
            item.knockBack = 5.5f;
            item.value = 1500;
            item.rare = 2;
            //  custom sound?
            //  item.UseSound = mod.GetLegacySoundSlot(SoundType.Item, "Sounds/Item/*");
            //  or vanilla sound?
            item.UseSound = SoundID.Item1;
            //  yes or no?
            item.autoReuse = false;
            item.melee = true;
            //  vanilla shooting method
            //  alternative sword usage
            //  item.shoot = mod.ProjectileType("cinnabar_dagger");
            //  item.useAmmo = mod.ItemType<cinnabar_dagger>();
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(mod.ItemType<cinnabar_bar>(), 8);
            recipe.AddIngredient(mod.ItemType<cinnabar_crystal>(), 4);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }

        public override bool UseItem(Player player)
        {
            return true;
        }
    }
}
