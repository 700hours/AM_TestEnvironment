﻿using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using TestEnvironment.NPCs;

namespace TestEnvironment.Items.Summons
{
    public class boss_summon : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Magnoliac Fossil");
            Tooltip.SetDefault("Seemed to of red and"
                +   "\ngray glowing quality");
        }
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.useTime = 45;
            item.useAnimation = 45;
            item.useStyle = 4;
            item.value = 100;
            item.rare = 2;
            item.autoReuse = false;
            item.consumable = true;
            item.noMelee = true;
        }
        public override void AddRecipes()
        {
            ModRecipe recipeT = new ModRecipe(mod);
            recipeT.AddIngredient(9);
            recipeT.SetResult(this, 1);
            recipeT.AddRecipe();
            // -- //
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(mod.ItemType<magno_bar>(), 5);
            recipe.AddIngredient(mod.ItemType<magno_core>(), 1);
            recipe.AddTile(TileID.Anvils);
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }

        bool flag = false;
        bool isActive;
        int spawn;
        public override bool CanUseItem(Player player)
        {
            TestPlayer modPlayer = player.GetModPlayer<TestPlayer>(mod);

            foreach (NPC n in Main.npc)
            {
                if (n.active && n.type == mod.NPCType("boss_magnohead"))
                {
                    isActive = true;
                    break;
                }
                else isActive = false;
            }

            return modPlayer.MagnoZone && !isActive;
        }
        public override bool UseItem(Player player)
        {   
            NPC.SpawnOnPlayer(player.whoAmI, mod.NPCType<boss_magnohead>());
            return true;
        }
    }
}
