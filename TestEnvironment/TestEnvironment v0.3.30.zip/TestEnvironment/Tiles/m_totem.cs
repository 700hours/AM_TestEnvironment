﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using Terraria;
using Terraria.DataStructures;
using Terraria.Enums;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace TestEnvironment.Tiles
{
    public class m_totem : ModTile
    {
        public override void SetDefaults()
        {
            Main.tileSpelunker[Type] = true;
            Main.tileShine2[Type] = true;
            Main.tileShine[Type] = 1200;
            Main.tileFrameImportant[Type] = true;
            Main.tileLavaDeath[Type] = false;
            Main.tileSolid[Type] = false;
            Main.tileMergeDirt[Type] = false;
            Main.tileLighted[Type] = true;
            Main.tileBlockLight[Type] = false;
            Main.tileNoSunLight[Type] = false;
            Main.tileNoAttach[Type] = true;
            TileObjectData.newTile.CopyFrom(TileObjectData.Style2x2);
            TileObjectData.newTile.Origin = new Point16(0, 1);
            TileObjectData.newTile.CoordinateHeights = new int[] { 16, 16 };
            TileObjectData.newTile.HookCheck = new PlacementHook(new Func<int, int, int, int, int, int>(Chest.FindEmptyChest), -1, 0, true);
            TileObjectData.newTile.HookPostPlaceMyPlayer = new PlacementHook(new Func<int, int, int, int, int, int>(Chest.AfterPlacement_Hook), -1, 0, false);
            TileObjectData.newTile.AnchorInvalidTiles = new int[] { 127 };
            TileObjectData.newTile.StyleHorizontal = true;
            TileObjectData.newTile.LavaDeath = false;
            TileObjectData.newTile.AnchorBottom = new AnchorData(AnchorType.SolidTile | AnchorType.SolidWithTop | AnchorType.SolidSide, TileObjectData.newTile.Width, 0);
            TileObjectData.addTile(Type);
            ModTranslation name = CreateMapEntryName();
            name.SetDefault("Crimson Totem");
            AddMapEntry(new Color(110, 210, 110), name);
            disableSmartCursor = true;
        }

        public override void ModifyLight(int i, int j, ref float r, ref float g, ref float b)
        {
            r = 0.604f;
            g = 0.161f;
            b = 0.161f;
        }
        public override bool CanKillTile(int i, int j, ref bool blockDamaged)
        {
            return false;
        }

        bool flag;
        int dustCircle;
        float degrees;
        float radius = 384f;
        const float radians = 0.017f;
        public override void PostDraw(int i, int j, SpriteBatch spriteBatch)
        {
            Player player = Main.LocalPlayer;
            TestPlayer modPlayer = player.GetModPlayer<TestPlayer>(mod);

            Vector2 tilev = new Vector2(i * 16, j * 16);
            if (Vector2.Distance(player.position - new Vector2(i * 16, j * 16), Vector2.Zero) < radius)
            {
                degrees += radians * 9f;
            //  int playerDust = Dust.NewDust(player.position, player.width, player.height, 159, 0f, 0f, 0, default(Color), 1f);
                int closeDust = Dust.NewDust(tilev, 32, 32, 159, 0f, 0f, 0, default(Color), 1f);
                Main.dust[closeDust].position.X = new Vector2(i * 16, j * 16).X + (float)(radius * Math.Cos(degrees));
                Main.dust[closeDust].position.Y = new Vector2(i * 16, j * 16).Y + (float)(radius * Math.Sin(degrees));

                player.AddBuff(mod.BuffType("magno_uncursed"), 60, false);
            }
        /*  degrees += radians * 4.5f;
            float radius = radians * 360f;
            float Point = (float)(radius * Math.Cos(degrees));
            float intensity = (radius - Point) / radius;

            Vector2 zero = new Vector2(Main.offScreenRange, Main.offScreenRange);
            if (Main.drawToScreen)
            {
                zero = Vector2.Zero;
            }

            Rectangle size = new Rectangle(0, 0, 528, 528);

            spriteBatch.Draw(Main.magicPixel,
            new Vector2(i * 16 - (int)Main.screenPosition.X, j * 16 - (int)Main.screenPosition.Y) + zero,
            size, Color.IndianRed * 0.1f, degrees, new Vector2(size.Width / 2, size.Height / 2),
            intensity, SpriteEffects.None, 0f); */
        }

        public override void MouseOver(int i, int j)
        {
            Player player = Main.LocalPlayer;
            player.showItemIcon2 = mod.ItemType("magno_trophy");
            player.showItemIcon = true;
        }
        public override void MouseOverFar(int i, int j)
        {
            MouseOver(i, j);
        }
    }
}
