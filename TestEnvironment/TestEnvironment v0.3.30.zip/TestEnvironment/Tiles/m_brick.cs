﻿using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;

namespace TestEnvironment.Tiles
{
    public class m_brick : ModTile
    {
        public override void SetDefaults()
        {
            Main.tileSolid[Type] = true;
            Main.tileMergeDirt[Type] = true;
            Main.tileBlockLight[Type] = true;
            Main.tileLighted[Type] = false;
            drop = mod.ItemType("magno_brick");
            //  UI map tile color
            AddMapEntry(new Color(119, 111, 98));
        }
    }
}