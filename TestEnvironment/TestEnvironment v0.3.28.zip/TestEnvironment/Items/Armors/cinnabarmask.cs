﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using TestEnvironment.Projectiles;

namespace TestEnvironment.Items.Armors
{
    [AutoloadEquip(EquipType.Head)]
    public class cinnabarmask : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Cinnabar Mask");
        }
        public override void SetDefaults()
        {
            item.width = 18;
            item.height = 18;
            item.maxStack = 1;
            item.value = 100;
            item.rare = 2;
            item.defense = 5;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(9);
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }
        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == mod.ItemType<cinnabarplate>() && legs.type == mod.ItemType<cinnabargreaves>();
        }

        bool spawnOK = false;
        int ticks = 0;
        int buffer = 256;
        int x, y;
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Generates lethal spores";

            ticks++;
            
            if (ticks % 60 == 0)
            {
                int newProj = Projectile.NewProjectile(player.Center, Vector2.Zero, mod.ProjectileType("cinnabar_spore"), 14, 4f, player.whoAmI, x, y);
            }
        }

        public bool TileCheck(int i, int j)
        {
        //  bool Dirt = Main.tile[i, j].type == TileID.Dirt;
            bool Active = Main.tile[i, j].active() == true;
            bool Solid = Main.tileSolid[Main.tile[i, j].type] == true;

            if (Solid && Active) return true;
            else return false;
        }
    }
}
