﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment.Items.Armors
{
    [AutoloadEquip(EquipType.Head)]
    public class magnohelmet : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Magno Helmet");
        }
        public override void SetDefaults()
        {
            item.width = 18;
            item.height = 18;
            item.maxStack = 1;
            item.value = 100;
            item.rare = 2;
            item.defense = 5;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(9);
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }
        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == mod.ItemType("magnoplate") && legs.type == mod.ItemType("magnogreaves");
        }

        bool flag = false;
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "Summons a Magno minion to"
                +   "\nyour aid when in dire need";

            TestPlayer modPlayer = player.GetModPlayer<TestPlayer>(mod);

            if (!flag && player.statLife <= player.statLifeMax / 2)
            {
                if (player.ownedProjectileCounts[mod.ProjectileType("magno_minion")] < player.maxMinions && player.numMinions < player.maxMinions)
                {
                    player.AddBuff(mod.BuffType("magno_summon"), 18000, false);
                    Main.PlaySound(mod.GetLegacySoundSlot(SoundType.Custom, "Sounds/Custom/conjure"), player.Center);
                    int projMinion = Projectile.NewProjectile(player.position, Vector2.Zero, mod.ProjectileType("magno_minion"), 5, 3f, player.whoAmI, 0f, 0f);
                    player.maxMinions += 1;
                }
                flag = true;
            }
            else flag = false;
        }
    }
}
