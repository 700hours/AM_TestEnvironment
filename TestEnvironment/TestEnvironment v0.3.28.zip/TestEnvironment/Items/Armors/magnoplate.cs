﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using TestEnvironment.Projectiles;

namespace TestEnvironment.Items.Armors
{
    [AutoloadEquip(EquipType.Body)]
    public class magnoplate : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Magno Breastplate");
            //  need to update tooltip with full set
            //  Tooltip.SetDefault("Generates protective shield"
            //          +   "\nEach shield can take four hits");
        }
        public override void SetDefaults()
        {
            item.width = 18;
            item.height = 18;
            item.maxStack = 1;
            item.value = 100;
            item.rare = 2;
            item.defense = 5;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(9);
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }
    }
}
