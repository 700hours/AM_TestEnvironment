﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using TestEnvironment.Projectiles;

namespace TestEnvironment.Items.Armors
{
    [AutoloadEquip(EquipType.Head)]
    public class cinnabarhelmet : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Cinnabar Helmet");
        }
        public override void SetDefaults()
        {
            item.width = 18;
            item.height = 18;
            item.maxStack = 1;
            item.value = 100;
            item.rare = 2;
            item.defense = 5;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(9);
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }
        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == mod.ItemType<cinnabarplate>() && legs.type == mod.ItemType<cinnabargreaves>();
        }

        public override void UpdateArmorSet(Player player)
        {
            Item item = player.inventory[player.selectedItem];

            player.setBonus = "20% increased melee speed";
            player.meleeSpeed /= 0.20f;
        }
    }
}
