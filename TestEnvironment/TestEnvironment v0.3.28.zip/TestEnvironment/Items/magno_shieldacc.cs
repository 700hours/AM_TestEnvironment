﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using TestEnvironment.Projectiles;

namespace TestEnvironment.Items
{
    public class magno_shieldacc : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Magnoliac Projection");
            Tooltip.SetDefault("Casts orbiting protective shields");
        }
        public override void SetDefaults()
        {
            item.width = 24;
            item.height = 32;
            item.value = 15000;
            item.rare = 9;
            item.expert = true;
            item.accessory = true;
            item.defense = 2;
        }
        // test recipe
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(9);
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }

        bool shield = false;
        int Proj;
        int ticks = 300;
        int totalShields = 0;
        float radius = 96f;
        float degrees = 67.5f;
        float ProjX, ProjY;
        const float radians = 0.017f;
        Vector2 playerCenter;
        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            TestPlayer modPlayer = player.GetModPlayer<TestPlayer>(mod);

            playerCenter = new Vector2(player.position.X + player.width / 2, player.position.Y + player.height / 2);
            if (!shield)
            {
                for (int l = 0; l < 4; l++)
                {
                    ProjX = playerCenter.X + (float)(radius * Math.Cos(degrees * l));
                    ProjY = playerCenter.Y + (float)(radius * Math.Sin(degrees * l));
                    Proj = Projectile.NewProjectile(new Vector2(ProjX, ProjY), Vector2.Zero, mod.ProjectileType<m_shield>(), 0, 0f, player.whoAmI, degrees * l, 0f);
                }
                // play sound
                Main.PlaySound(mod.GetLegacySoundSlot(SoundType.Custom, "Sounds/Custom/conjure"), player.Center);
                shield = true;
            }
            if (player.ownedProjectileCounts[mod.ProjectileType<m_shield>()] < 4)
            {
                ticks--;
                if (ticks == 0)
                {
                    foreach(Projectile p in Main.projectile)
                    {
                        if(p.active && p.owner == player.whoAmI && p.type == mod.ProjectileType<m_shield>())
                        {
                            p.active = false;
                        }
                    }
                    shield = false;
                    ticks = 600;
                }
            }
            else if (player.ownedProjectileCounts[mod.ProjectileType<m_shield>()] == 0)
            {
                shield = false;
            }
        }
    }
}
