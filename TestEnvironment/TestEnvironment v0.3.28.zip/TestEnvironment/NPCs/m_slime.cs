﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment.NPCs
{
    public class m_slime : ModNPC
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Magnoliac Slime");
            Main.npcFrameCount[npc.type] = 3;
            //  to circumvent custom spawning net code
            //  unnecessary for final version
            Main.npcCatchable[npc.type] = true;
        }
        public override void SetDefaults()
        {
            npc.width = 38;
            npc.height = 28;
            npc.friendly = false;
            npc.aiStyle = 1;
            npc.damage = 10;
            npc.defense = 4;
            npc.lifeMax = 80;
            npc.HitSound = SoundID.NPCHit1;
            npc.DeathSound = SoundID.NPCDeath1;
            npc.knockBackResist = 1f;
        }

        public void Initialize()
        {
            npc.TargetClosest(true);
        }
        bool init;
        int ticks;
        int active = 300;
        public override void AI()
        {
            if (!init)
            {
                Initialize();
                init = true;
            }
            if (npc.life < npc.lifeMax && (npc.target < 0 || npc.target == 255 || Main.player[npc.target].dead || !Main.player[npc.target].active))
            {
                npc.TargetClosest(true);
            }
            ticks++;
        }
        bool frameAdd = false;
        int num, frame;
        int FrameY;
        public override void FindFrame(int frameHeight)
        {
            if (!Main.dedServ)
                num = Main.npcTexture[npc.type].Height / Main.npcFrameCount[npc.type];

            if (npc.velocity.Y == 0)
            {
                if (frameAdd && ticks % 10 == 0 && frame < 2)
                    frame++;
                else if (ticks % 10 == 0 && frame > 0)
                    frame--;
                if (frame == 0) frameAdd = true;
                if (frame == 2) frameAdd = false;
            }
            else frame = 0;
            
            npc.frame.Y = num * frame;
            FrameY = npc.frame.Y;
        }

        public override float SpawnChance(NPCSpawnInfo spawnInfo)
        {
            TestPlayer modPlayer = spawnInfo.player.GetModPlayer<TestPlayer>(mod);

            if (spawnInfo.playerSafe)
            {
                return 0f;
            }
            if (SpawnCondition.Underground.Chance > 0f && modPlayer.MagnoZone)
            {
                return SpawnCondition.Underground.Chance / 2f;
            }
            else return 0f;
        }
        float degrees;
        float Point;
        const float radians = 0.017f;
        Color alternateColor;
        public override void PostDraw(SpriteBatch spriteBatch, Color drawColor)
        {
            degrees += radians * 4.5f;
            Point = (float)(16 * Math.Cos(degrees));
            alternateColor = new Color(Vector3.Lerp(new Vector3(0.8f, 0.8f, 0.8f), new Vector3(0.8f, 0.361f, 0.361f), (MathHelper.ToRadians(360) - Point) / MathHelper.ToRadians(360)));

            spriteBatch.Draw(mod.GetTexture("Gores/magno_slimeglow"),
                new Vector2(npc.position.X + npc.width / 2, npc.position.Y + npc.height / 2 + 4) - Main.screenPosition, 
                new Rectangle(0, FrameY, npc.width, npc.height),
                alternateColor, 0f, new Vector2(npc.width / 2, npc.height / 2), 1f, SpriteEffects.None, 0f);
        }
    }
}
