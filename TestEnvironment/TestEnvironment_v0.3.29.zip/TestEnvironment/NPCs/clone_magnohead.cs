﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment.NPCs
{
    public class clone_magnohead : ModNPC
    {
        public override void SetDefaults()
        {
            npc.width = 64;
            npc.height = 128;
            npc.scale = 0.6f;
            npc.color = Color.Gold;
            npc.friendly = false;
            npc.aiStyle = 6;
            //  aiType = NPCID.Worm;
            npc.boss = true;
            npc.noTileCollide = true;
            npc.noGravity = true;
            npc.behindTiles = true;
            npc.damage = 35;
            npc.defense = 6;
            npc.lifeMax = 1260;
            npc.HitSound = SoundID.NPCHit1;
            npc.DeathSound = SoundID.NPCDeath1;
            npc.knockBackResist = 0f;
        }

        bool TailSpawned = false;
        bool flames = false;
        bool pupsSpawned = false;
        bool magnoClone = false;
        int Previous = 255, digger = 0, despawn = 210;
        int pups = 255, clone = 255, timeLeft = 600;
        int flamesID = 255;
        int ticks = 0;
        float TargetAngle, PlayerAngle;
        float degrees = 0, radius = 64;
        float Depreciate = 80, Point;
        const float Time = 80;
        const float radians = 0.017f;
        Rectangle target;
        Vector2 oldPosition, newPosition;
        Vector2 npcCenter, playerCenter, center;
        Vector2 Start, End;
        public override void AI()
        {
            #region spawn parts
            if (npc.ai[0] <= 1 || npc.ai[0] >= 400)
            {
                //  npc.damage = 35;
                //  Main.npc[digger].damage = 35;
                if (!TailSpawned)
                {
                    Previous = npc.whoAmI;
                    int offset = 32;
                    for (int num36 = 0; num36 < 14; num36++)
                    {
                        if (num36 >= 0 && num36 < 13)
                        {
                            digger = NPC.NewNPC((int)npc.position.X + npc.width / 2, (int)npc.position.Y + npc.height / 2, mod.NPCType("clone_magnobody"), npc.whoAmI);
                        }
                        else
                        {
                            digger = NPC.NewNPC((int)npc.position.X + npc.width / 2, (int)npc.position.Y + npc.height / 2, mod.NPCType("clone_magnotail"), npc.whoAmI);
                        }
                        Main.npc[digger].scale = npc.scale;
                        Main.npc[digger].lifeMax = npc.lifeMax;
                        Main.npc[digger].life = Main.npc[digger].lifeMax;
                        Main.npc[digger].realLife = npc.whoAmI;
                        Main.npc[digger].ai[2] = (float)npc.whoAmI;
                        Main.npc[digger].ai[1] = (float)Previous;
                        Main.npc[Previous].ai[0] = (float)digger;
                        if (Main.netMode == 2)
                        {
                            NetMessage.SendData(23, -1, -1, null, digger, 0f, 0f, 0f, 0, 0, 0);
                        }
                        Previous = digger;
                    }
                    npc.netUpdate = true;
                    TailSpawned = true;
                }
            }
            /*  else if (npc.ai[0] >= 2)
                {
                    npc.damage = 30;
                }   */
            if (npc.target < 0 || npc.target == 255 || Main.player[npc.target].dead || !Main.player[npc.target].active)
            {
                npc.TargetClosest(true);
            }
            if (!Main.player[npc.target].active || Main.player[npc.target].dead)
                despawn--;
            if (despawn <= 0)
                npc.active = false;
            #endregion
        }
    }
}
