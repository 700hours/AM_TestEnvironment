﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment.Buffs
{
    class magno_summon : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Magno Fly");
            Description.SetDefault("Chemically enhanced minion");
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            TestPlayer modPlayer = player.GetModPlayer<TestPlayer>(mod);
            if (player.ownedProjectileCounts[mod.ProjectileType("magno_minion")] > 0)
            {
                modPlayer.magnoMinion = true;
            }
            if (!modPlayer.magnoMinion)
            {
                player.DelBuff(buffIndex);
                buffIndex--;
            }
            else
            {
                player.buffTime[buffIndex] = 18000;
            }
        }
    }
}
