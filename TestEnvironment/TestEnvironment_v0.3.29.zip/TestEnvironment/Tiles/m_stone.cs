﻿using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;
using Microsoft.Xna.Framework.Graphics;

namespace TestEnvironment.Tiles
{
    public class m_stone : ModTile
    {
        public override void SetDefaults()
        {
            Main.tileSolid[Type] = true;
            Main.tileMergeDirt[Type] = true;
            Main.tileBlockLight[Type] = true;
            Main.tileLighted[Type] = false;
            drop = mod.ItemType("magno_stone");
            //  UI map tile color
            AddMapEntry(new Color(119, 111, 98));
        }
    //  need to add waters namespace
/*      public override void ChangeWaterfallStyle(ref int style)
        {
            style = mod.GetWaterfallStyleSlot("MagnoWaterfall");
        }   */

        public override bool PreDraw(int i, int j, SpriteBatch spriteBatch)
        {
            #region psudo update

            mineResist = 2.5f;
            minPick = 35;

            #endregion
            return true;
        }
    }
}
