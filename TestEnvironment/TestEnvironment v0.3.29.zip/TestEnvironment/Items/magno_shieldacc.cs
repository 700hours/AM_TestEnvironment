﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using TestEnvironment.Projectiles;

namespace TestEnvironment.Items
{
    public class magno_shieldacc : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Magnoliac Projection");
            Tooltip.SetDefault("Casts orbiting protective shields");
        }
        public override void SetDefaults()
        {
            item.width = 24;
            item.height = 32;
            item.value = 15000;
            item.rare = 9;
            item.expert = true;
            item.accessory = true;
            item.defense = 2;
        }

        bool shield = false;
        int Proj;
        int ticks = 900;
        int shieldCount;
        float radius = 96f;
        float degreeS = 67.5f;
        float ProjX, ProjY;
        const float radians = 0.017f;
        int[] shieldID = new int[4];
        Vector2 playerCenter;
        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            TestPlayer modPlayer = player.GetModPlayer<TestPlayer>(mod);
            
            playerCenter = new Vector2(player.position.X + player.width / 2, player.position.Y + player.height / 2);
            float degrees = MathHelper.ToRadians(90f);
            if (!shield)
            {
                for (int k = 0; k < 4; k++)
                {
                    ProjX = playerCenter.X + (float)(radius * Math.Cos(degrees * k));
                    ProjY = playerCenter.Y + (float)(radius * Math.Sin(degrees * k));
                    shieldID[k] = Projectile.NewProjectile(new Vector2(ProjX, ProjY), Vector2.Zero, mod.ProjectileType<m_shield>(), 0, 0f, player.whoAmI, degrees * k, 0f);
                }
                // play sound
                Main.PlaySound(mod.GetLegacySoundSlot(SoundType.Custom, "Sounds/Custom/conjure"), player.Center);
                shield = true;
            }

            if (player.ownedProjectileCounts[mod.ProjectileType<m_shield>()] == 4)
            {
                for (int l = 1; l < 4; l++)
                {
                    int shield1 = (int)Math.Round(MathHelper.ToDegrees(Main.projectile[shieldID[l - 1]].rotation), 0);
                    int shield2 = (int)Math.Round(MathHelper.ToDegrees(Main.projectile[shieldID[l]].rotation), 0);
                    if (shield2 >= 260 && shield2 <= 280 || shield2 <= -80 && shield2 >= -100)
                    {
                        if (shield1 >= 260 && shield1 <= 280 || shield1 <= -80 && shield1 >= -100 || shield1 >= 160 && shield1 <= 190)
                        {
                        }
                        else
                        {
                        //  troubleshooting message
                        //  Main.NewText("Rotation 1: " + shield1 + " Rotation 2: " + shield2, 200, 150, 100);
                            shield = false;
                        }
                    }
                }
            }
            

            if (player.ownedProjectileCounts[mod.ProjectileType<m_shield>()] < 4)
            {
                ticks--;
                if (ticks == 0)
                {
                    foreach(Projectile p in Main.projectile)
                    {
                        if(p.active && p.owner == player.whoAmI && p.type == mod.ProjectileType<m_shield>())
                        {
                            p.active = false;
                        }
                    }
                    shield = false;
                    ticks = 900;
                }
            }
            else if (player.ownedProjectileCounts[mod.ProjectileType<m_shield>()] == 0)
            {
                shield = false;
            }
            if (player.ownedProjectileCounts[mod.ProjectileType<m_shield>()] > 4)
            {
                foreach (Projectile p in Main.projectile)
                {
                    if (p.active && p.owner == player.whoAmI && p.type == mod.ProjectileType<m_shield>())
                    {
                        p.active = false;
                    }
                }
                shield = false;
                ticks = 600;
            }
        }
    }
}
