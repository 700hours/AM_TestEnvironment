﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment.NPCs
{
    public class clone_magnohead : ModNPC
    {
        public override void SetDefaults()
        {
            npc.width = 64;
            npc.height = 64;
            npc.scale = 0.6f;
            npc.color = Color.Gold;
            npc.alpha = 255;
            npc.friendly = false;
            npc.aiStyle = 6;
            //  aiType = NPCID.Worm;
            npc.noTileCollide = true;
            npc.noGravity = true;
            npc.behindTiles = true;
            npc.damage = 35;
            npc.defense = 6;
            npc.lifeMax = 280;
            npc.HitSound = SoundID.NPCHit1;
            npc.DeathSound = SoundID.NPCDeath1;
            npc.knockBackResist = 0f;
        }
        
        bool spawned;
        int Previous;
        float degrees;
        const float radians = 0.017f;
        Vector2 center;
        int[] parts = new int[5];
        public override void AI()
        {
            #region spawn parts
            Previous = npc.whoAmI;
            if (!spawned)
            {
                for (int i = 0; i < parts.Length; i++)
                {
                    if (i != 4)
                    {
                        parts[i] = NPC.NewNPC((int)npc.Center.X, (int)npc.Center.Y, mod.NPCType<clone_magnobody>(), npc.whoAmI, npc.whoAmI);
                    }
                    else
                    {
                        parts[i] = NPC.NewNPC((int)npc.Center.X, (int)npc.Center.Y, mod.NPCType<clone_magnotail>(), npc.whoAmI, npc.whoAmI);
                    }
                    if (Main.netMode == 2)
                    {
                        NetMessage.SendData(23, -1, -1, null, parts[i], 0f, 0f, 0f, 0, 0, 0);
                    }
                    NPC nme = Main.npc[parts[i]];
                    nme.scale = npc.scale;
                    nme.target = npc.target;
                    nme.scale = npc.scale;
                    nme.lifeMax = npc.lifeMax;
                    nme.realLife = npc.whoAmI;
                    nme.ai[2] = npc.whoAmI;
                    nme.ai[1] = Previous;
                    Main.npc[Previous].ai[0] = parts[i];
                    Previous = parts[i];

                    spawned = true;
                }
            }
            #endregion

            if(npc.alpha > 0)
            {
                npc.alpha--;
            }
            if(!Main.npc[(int)npc.ai[0]].active)
            {
                npc.active = false;
            }
            if (npc.target < 0 || npc.target == 255 || Main.player[npc.target].dead || !Main.player[npc.target].active)
            {
                npc.TargetClosest(true);
            }

            Player player = Main.player[npc.target];

            center = new Vector2(player.Center.X - npc.width / 2, player.Center.Y - npc.height / 2);

            float radius = 256f;
            degrees += radians * 2.25f;

            npc.position.X = center.X + (float)(radius * Math.Cos(degrees));
            npc.position.Y = center.Y + (float)(radius * Math.Sin(degrees));

            float faceAngle = (float)Math.Atan2(player.position.Y - npc.position.Y, player.position.X - npc.position.X);

            npc.rotation = faceAngle;
        }
    }
}
