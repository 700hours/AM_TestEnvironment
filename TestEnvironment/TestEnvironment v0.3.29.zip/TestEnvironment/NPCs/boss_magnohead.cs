﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using TestEnvironment.Projectiles;

namespace TestEnvironment.NPCs
{
    public class boss_magnohead : ModNPC
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Magnoliac Entity");
        }
        public override void SetDefaults()
        {
            npc.width = 54;
            npc.height = 46;
            npc.scale = 1.3f;
            npc.friendly = false;
            npc.aiStyle = 6;
          //aiType = NPCID.Worm;
            npc.boss = true;
            npc.noTileCollide = true;
            npc.noGravity = true;
            npc.behindTiles = true;
            npc.damage = 35;
            npc.defense = 6;
            npc.lifeMax = 8050;
            npc.npcSlots = 15f;
            //  custom or vanilla sounds?
            npc.HitSound = SoundID.NPCHit1;
            //  npc.DeathSound = SoundID.NPCDeath1;
            npc.knockBackResist = 0f;
            bossBag = mod.ItemType("magno_treasurebag");
        }

        bool TailSpawned = false;
        bool flames = false;
        bool pupsSpawned = false;
        bool magnoClone = false;
        bool soundOnce = false;
        bool part2 = false;
        bool towerAbove = false;
        bool set1 = false, set2 = false;
        bool goLeft = false, goRight = false;
        bool ProjActive = false;
        int Previous, digger, despawn = 210;
        int timeLeft = 600;
        int flamesID;
        int extraTimer = 90;
        int Proj1 = 0, Proj2 = 0;
        float TargetAngle, PlayerAngle;
        float degrees = 0, radius = 64;
        float Depreciate = 80, Point;
        float WaveTimer;
        const float Time = 80;
        const float radians = 0.017f;
        Rectangle target;
        Vector2 oldPosition, newPosition;
        Vector2 npcCenter, playerCenter, center;
        Vector2 Start, End;
        Vector2 lootPos;
        /// <summary>
        /// reorganize declarations
        /// </summary>

        bool spawned;
        bool flag = true;
        int ticks;
        int attack;
        int clone;
        int pups;
        int core;
        int[] MagnoParts = new int[8];
        int[] numPets = new int[3];
        
        public override void AI()
        {
            Player player = Main.player[npc.target];
            npcCenter = new Vector2(npc.position.X + npc.width / 2, npc.position.Y + npc.height / 2);

            if (npc.target < 0 || npc.target == 255 || Main.player[npc.target].dead || !Main.player[npc.target].active)
            {
                npc.TargetClosest(true);
            }

            if (ticks < 1800) ticks++;
            else ticks = 0;

            #region spawn parts
            Previous = npc.whoAmI;
            if (!spawned)
            {
                for (int i = 0; i < MagnoParts.Length; i++)
                {
                    if (i != 7)
                    {
                        MagnoParts[i] = NPC.NewNPC((int)npc.Center.X, (int)npc.Center.Y, mod.NPCType<boss_magnobody>(), npc.whoAmI);
                    }
                    else
                    {
                        MagnoParts[i] = NPC.NewNPC((int)npc.Center.X, (int)npc.Center.Y, mod.NPCType<boss_magnotail>(), npc.whoAmI);
                        core = NPC.NewNPC((int)npc.Center.X, (int)npc.Center.Y, mod.NPCType<m_core>(), npc.whoAmI, npc.whoAmI);
                    }
                    if (Main.netMode == 2)
                    {
                        NetMessage.SendData(23, -1, -1, null, MagnoParts[i], 0f, 0f, 0f, 0, 0, 0);
                    }
                    NPC nme = Main.npc[MagnoParts[i]];
                    nme.target = npc.target;
                    nme.scale = npc.scale;
                    nme.lifeMax = npc.lifeMax;
                    nme.realLife = npc.whoAmI;
                    nme.ai[2] = npc.whoAmI;
                    nme.ai[1] = Previous;
                    Main.npc[Previous].ai[0] = MagnoParts[i];
                    Previous = MagnoParts[i];

                    spawned = true;
                }
            }
            NPC HeadCore = Main.npc[core];
            HeadCore.Center = npc.Center;
            HeadCore.rotation = npc.rotation;
            if (HeadCore.life > 0 || HeadCore.active)
                npc.dontTakeDamage = true;
            else npc.dontTakeDamage = false;
            #endregion

            #region movement variation
            if (ticks % 600 == 0)
            {
                extraTimer = 180;
                towerAbove = true;
            }
            if (towerAbove)
            {
                extraTimer--;
                npc.velocity = Vector2.Zero;
                if (npc.position.Y < player.position.Y - 256f)
                {
                    if(!set2)
                    {
                        if (player.position.X <= npc.position.X)
                            goLeft = true;
                        if (player.position.X >= npc.position.X)
                            goRight = true;
                        set2 = true;
                    }
                    if (goLeft)
                    {
                        npc.position.X -= 8f;
                        npc.rotation = MathHelper.ToRadians(270);
                    }
                    if (goRight)
                    {
                        npc.position.X += 8f;
                        npc.rotation = MathHelper.ToRadians(90);
                    }
                    set1 = true;
                }
                if (!set1)
                {
                    npc.position.Y -= 8f;
                    npc.rotation = 0;
                }
                // play sound, rush
                if (extraTimer == 0)
                {
                    set1 = false;
                    set2 = false;
                    goLeft = false;
                    goRight = false;
                    towerAbove = false;
                }
            }
            #endregion

            #region mouth flames
            if (Vector2.Distance(player.position - npc.position, Vector2.Zero) < 384f)
            {
                if (ticks % 10 == 0)
                {   
                    attack = Projectile.NewProjectile(npc.Center, Vector2.Zero, mod.ProjectileType("magno_flame"), 8 + Main.rand.Next(-2, 5), 0.5f, Main.myPlayer, 0f, 0f);
                    Projectile proj = Main.projectile[attack];
                    proj.velocity.X = Distance(null, npc.rotation + radians * 270f, 16f).X;
                    proj.velocity.Y = Distance(null, npc.rotation + radians * 270f, 16f).Y;
                    proj.timeLeft = 30;
                    proj.penetrate = 1;
                    proj.tileCollide = false;
                    proj.scale = 1.6f;
                    proj.alpha = 50;
                    proj.friendly = false;
                    proj.hostile = true;
                }
            }
            #endregion

            // bugged
            #region spirit flames
            /*  //  needs cleanup
            if (!flames && Main.rand.Next(0, 6000) == 0)
            {
                for (int k = 1; k < 4; k++)
                {
                    degrees = 67.5f;
                    radius = 128f;
                    center = player.position;
                    float nX = center.X + (float)(radius * Math.Cos(degrees * k));
                    float nY = center.Y + (float)(radius * Math.Sin(degrees * k));

                    if (npc.life > npc.lifeMax / 2 || Main.npc[digger].life > Main.npc[digger].lifeMax / 2)
                    {
                        flamesID = NPC.NewNPC((int)nX, (int)nY, mod.NPCType("m_flame"));
                        Main.npc[flamesID].damage = 10;
                    }
                    else
                    {
                        flamesID = NPC.NewNPC((int)nX, (int)nY, mod.NPCType("c_flame"));
                        Main.npc[flamesID].damage = 16;
                    }
                    Main.npc[flamesID].ai[1] = degrees * k;
                    Main.npc[flamesID].scale = 1.2f;
                    if (Main.netMode == 2)
                    {
                        NetMessage.SendData(23, -1, -1, null, flamesID, 0f, 0f, 0f, 0, 0, 0);
                    }
                    flames = true;
                }
                Main.PlaySound(mod.GetLegacySoundSlot(SoundType.Custom, "Sounds/Custom/curse"), npc.Center);
            }
            if (flames)
            {
                radius -= 0.5f;
                NPC n = Main.npc[flamesID];
                if (n.active = false || radius <= 1f)
                    flames = false;
            }
            */
            #endregion
            #region magno clone sequence
            // needs to sprite/code separate NPC for magno clone
            /*
            npcCenter = new Vector2(npc.position.X + npc.width / 2, npc.position.Y + npc.height / 2);
            if (!magnoClone)
            {
                if (!pupsSpawned && ticks == 900)
                {
                    ticks++;
                    numPets[0] = NPC.NewNPC((int)npcCenter.X + Main.rand.Next(-64, 64), (int)npcCenter.Y, mod.NPCType<m_puphead>(), 0, 0f);
                    if (Main.netMode == 2)
                    {
                        NetMessage.SendData(23, -1, -1, null, numPets[0], 0f, 0f, 0f, 0, 0, 0);
                    }
                    Main.PlaySound(mod.GetLegacySoundSlot(SoundType.Custom, "Sounds/Custom/conjure"), npc.Center);
                    pupsSpawned = true;
                }
                if (pupsSpawned)
                {
                    if (!Main.npc[numPets[0]].active)
                    {
                        pupsSpawned = false;
                        magnoClone = true;
                        flag = true;
                    }
                }
            }
            if (magnoClone)
            {
                if (flag)
                {
                    Main.PlaySound(mod.GetLegacySoundSlot(SoundType.Custom, "Sounds/Custom/conjure"), npc.Center);
                    clone = NPC.NewNPC((int)npc.Center.X, (int)npc.Center.Y, mod.NPCType<clone_magnohead>(), npc.whoAmI, npc.whoAmI);
                    if (Main.netMode == 2)
                    {
                        NetMessage.SendData(23, -1, -1, null, clone, 0f, 0f, 0f, 0, 0, 0);
                    }
                    Main.npc[clone].color = Color.Gold;
                    flag = false;
                }
                else
                {
                    magnoClone = false;
                }
            }
            if (Main.expertMode && Main.npc[clone].active)
            {
                npc.immortal = true;
                npc.dontTakeDamage = true;
            }
            if (!Main.npc[clone].active)
            {
                npc.immortal = false;
                npc.dontTakeDamage = false;
                flag = true;
                magnoClone = false;
            }   */
            #endregion

            // play NPC sound at half life
            if (npc.life < npc.lifeMax / 2 || Main.npc[digger].life < Main.npc[digger].lifeMax / 2)
            {
                if (!soundOnce)
                {
                    Main.PlaySound(mod.GetLegacySoundSlot(SoundType.Custom, "Sounds/Custom/blast"), npc.Center);
                    soundOnce = true;
                }
                part2 = true;
            } 
            foreach(Projectile proj in Main.projectile)
            {
                if(proj.Hitbox.Intersects(npc.Hitbox) && proj.friendly && proj.active && proj.type != 96)
                {
                    lootPos = proj.position;
                }
            }
        }

        public override bool SpecialNPCLoot()
        {
            return false;
        }
        public override void NPCLoot()
        {
            TestWorld modWorld = mod.GetModWorld<TestWorld>();
            modWorld.MagnoDefeated = true;

            Item.NewItem(lootPos, ItemID.Heart, 6, false, 0, false, false);
            if (Main.expertMode)
            {
                npc.DropBossBags();
                //  Item.NewItem(lootPos, mod.ItemType("magno_treasurebag"), 1, false, 0, false, false);
            }
            for(int k = 0; k < 4; k++)
            {
                Item.NewItem(lootPos, mod.ItemType("magno_fragment"), 8 + Main.rand.Next(2, 8), false, 0, false, false);
            }
            int choice = Main.rand.Next(10);
            int item = 0;
            switch (choice)
            {
                case 0:
                    item = mod.ItemType("magno_trophy");
                    break;
            }
            if (item != 0)
            {
                Item.NewItem(lootPos, item, 1, false, 0, true, false);
            }
        }

        public Vector2 Distance(Player player, float Angle, float Radius)
        {
            float VelocityX = (float)(Radius * Math.Cos(Angle));
            float VelocityY = (float)(Radius * Math.Sin(Angle));

            return new Vector2(VelocityX, VelocityY);
        }
    }
}
