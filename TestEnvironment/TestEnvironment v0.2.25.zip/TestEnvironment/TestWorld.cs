using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.World.Generation;
using Microsoft.Xna.Framework;
using Terraria.GameContent.Generation;
using Terraria.ModLoader.IO;
using Terraria.DataStructures;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Graphics;

namespace TestEnvironment
{
    public class TestWorld : ModWorld
    {
        public override void PostDrawTiles()
        {
            Main.spriteBatch.Begin(SpriteSortMode.Immediate, BlendState.AlphaBlend);

            if (!Main.playerInventory)
            {
                Main.spriteBatch.DrawString(Main.fontMouseText, "Test Environment v0.2.25", new Vector2(192, 160), Color.White, 0f, new Vector2(8, 8) + Main.fontMouseText.MeasureString("|-0-0-0-0-0-0-|"), 1f, SpriteEffects.None, 0f);
                Main.spriteBatch.DrawString(Main.fontMouseText, "Cost is 1 wood to craft items", new Vector2(192, 192), Color.White, 0f, new Vector2(8, 8) + Main.fontMouseText.MeasureString("|-0-0-0-0-0-0-|"), 1f, SpriteEffects.None, 0f);
            }

            Main.spriteBatch.End();
        }

        public override TagCompound Save()
        {
            var downed = new List<string>();
            if (MagnoDefeated) downed.Add("magno");

            return new TagCompound
            {
                { "downed", downed }
            };
        }
        public override void Load(TagCompound tag)
        {
            var downed = tag.GetList<string>("downed");
            MagnoDefeated = downed.Contains("magno");
        }
        public override void LoadLegacy(BinaryReader reader)
        {
            int loadVersion = reader.ReadByte();
            if (loadVersion == 0)
            {
                BitsByte flags = reader.ReadByte();
                MagnoDefeated = flags[0];
            }
            else
            {
                ErrorLogger.Log("Archaea Mod: Unknown loadVersion: " + loadVersion);
            }
        }
        public override void NetSend(BinaryWriter writer)
        {
            BitsByte flags = new BitsByte();
            flags[0] = MagnoDefeated;
            writer.Write(flags);
        }
        public override void NetReceive(BinaryReader reader)
        {
            BitsByte flags = reader.ReadByte();
            MagnoDefeated = flags[0];
        }

        public static int magnoTiles;
        public bool MagnoDefeated = false;
        public override void ResetNearbyTileEffects()
        {
            magnoTiles = 0;
        }
        public override void TileCountsAvailable(int[] tileCounts)
        {
            magnoTiles = tileCounts[mod.TileType<Tiles.m_dirt>()] + tileCounts[mod.TileType<Tiles.m_stone>()];
        }

        public static Miner miner = new Miner();
        int buffer = 16;
        int ID = 0;
        int ticks = 64;
        int[] HouseX = new int[2160000]; 
        int[] HouseY = new int[2160000]; 
        public override void ModifyWorldGenTasks(List<GenPass> tasks, ref float totalWeight)
        {
            int CavesIndex = tasks.FindIndex(genpass => genpass.Name.Equals("Granite"));
            if (CavesIndex != -1)
            {
                tasks.Insert(CavesIndex + 1, new PassLegacy("Miner " + Miner.progressText, delegate (GenerationProgress progress)
                {
                    for (int i = 0; miner.jobCount < miner.jobCountMax + miner.buffer; i++)
                    {
                        miner.Update();

                        progress.Message = "Miner " + Miner.progressText;
                    }
                }));
            }

            int OresIndex = tasks.FindIndex(genpass => genpass.Name.Equals("Shinies"));
            if (OresIndex != -1)
            {
                tasks.Insert(OresIndex + 1, new PassLegacy("Archaea Mod Shinies", delegate (GenerationProgress progress)
                {
                    progress.Message = "Archaea Mod Shinies";

                    for (int k = 0; k < (int)((Main.maxTilesX * Main.maxTilesY) * 6E-05); k++)
                    {
                        WorldGen.TileRunner(WorldGen.genRand.Next((int)(miner.genPos[0].X / 16) - miner.edge / 2, (int)(miner.genPos[1].X / 16) + miner.edge / 2), WorldGen.genRand.Next((int)miner.genPos[0].Y / 16 - miner.edge / 2, (int)miner.genPos[1].Y / 16 + miner.edge / 2), WorldGen.genRand.Next(15, 18), WorldGen.genRand.Next(2, 6), miner.mod.TileType<Tiles.m_dirt>(), false, 0f, 0f, false, true);
                        WorldGen.TileRunner(WorldGen.genRand.Next((int)(miner.genPos[0].X / 16) - miner.edge / 2, (int)(miner.genPos[1].X / 16) + miner.edge / 2), WorldGen.genRand.Next((int)miner.genPos[0].Y / 16 - miner.edge / 2, (int)miner.genPos[1].Y / 16 + miner.edge / 2), WorldGen.genRand.Next(9, 12), WorldGen.genRand.Next(2, 6), miner.mod.TileType<Tiles.m_ore>(), false, 0f, 0f, false, true);
                    }

                    int x = 0;
                    int y = 0;
                    int inflate = (int)Vector2.Distance(miner.genPos[0] - miner.genPos[1], Vector2.Zero);
                    if (inflate < 0) inflate *= (-1);
                    HouseX[0] = (int)miner.center.X;
                    HouseY[0] = (int)miner.center.Y;
                    for (int i = (int)miner.genPos[0].X / 16; i < (int)miner.genPos[1].X / 16; i++)
                    {
                        x = i;
                        for (int j = (int)miner.genPos[0].Y / 16; j < (int)miner.genPos[1].Y / 16; j++)
                        {
                            y = j;
                            if (Main.tile[x, y].active())
                            {
                                ID++;
                                HouseX[ID] = x;
                                HouseY[ID] = y;
                            }
                        }
                    }
                    for (int k = 0; k < HouseX.Length - 1; k++)
                    {
                        for (int m = HouseY[k] - buffer * 2; m < HouseY[k]; m++)
                        {
                            ticks++;
                            if (HouseX[k] != 0 && ticks % 20600 == 0)
                            {
                                if (!Main.tile[HouseX[k] + buffer / 2, m - 1].active() && Main.tile[HouseX[k], HouseY[k]].type == mod.TileType<Tiles.m_stone>())
                                {
                                    PlaceHouse(HouseX[k], HouseY[k]);
                                }
                            }
                        }
                    }

                    for (int k = 0; k < (int)((Main.maxTilesX * Main.maxTilesY) * 6E-05); k++)
                    {
                        #region crystal runners
                        bool success2x2 = false;
                        Tile tile2x2;
                        int placeTile2x2 = miner.mod.TileType<Tiles.c_crystal2x2>();
                        int attempts2x2 = 0;
                        int maxAttempts2x2 = 64;
                        while (!success2x2 && attempts2x2 < maxAttempts2x2)
                        {
                            attempts2x2++;
                            x = WorldGen.genRand.Next((int)miner.genPos[0].X / 16, (int)miner.genPos[1].X / 16);
                            y = WorldGen.genRand.Next((int)miner.genPos[0].Y / 16, (int)miner.genPos[1].Y / 16);
                            WorldGen.PlaceTile(x, y, placeTile2x2);
                            tile2x2 = Main.tile[x, y];
                            success2x2 = tile2x2.active() && tile2x2.type == placeTile2x2;
                        }

                        bool success2x1 = false;
                        Tile tile2x1;
                        int placeTile2x1 = miner.mod.TileType<Tiles.c_crystal2x1>();
                        int attempts2x1 = 0;
                        int maxAttempts2x1 = 64;
                        while (!success2x1 && attempts2x1 < maxAttempts2x1)
                        {
                            attempts2x1++;
                            x = WorldGen.genRand.Next((int)miner.genPos[0].X / 16, (int)miner.genPos[1].X / 16);
                            y = WorldGen.genRand.Next((int)miner.genPos[0].Y / 16, (int)miner.genPos[1].Y / 16);
                            WorldGen.PlaceTile(x, y, placeTile2x1);
                            tile2x1 = Main.tile[x, y];
                            success2x1 = tile2x1.active() && tile2x1.type == placeTile2x1;
                        }

                        bool successSmall = false;
                        Tile tileSmall;
                        Tile tile2;
                        int placeTileSmall = miner.mod.TileType<Tiles.c_crystalsmall>();
                        int placeTileWall = miner.mod.TileType<Tiles.c_crystalwall>();
                        int attemptsSmall = 0;
                        int maxAttemptsSmall = 194;
                        while (!successSmall  && attemptsSmall < maxAttemptsSmall)
                        {
                            attemptsSmall++;
                            x = WorldGen.genRand.Next((int)miner.genPos[0].X / 16, (int)miner.genPos[1].X / 16);
                            y = WorldGen.genRand.Next((int)miner.genPos[0].Y / 16, (int)miner.genPos[1].Y / 16);
                            if (Main.tile[x, y].wall == 0)
                            {
                                WorldGen.PlaceTile(x, y, placeTileWall);
                            }
                            tileSmall = Main.tile[x, y];
                            successSmall = tileSmall.active() && (tileSmall.type == placeTileSmall || tileSmall.type == placeTileWall); //(Main.tile[x, y + 1].type == placeTileSmall || Main.tile[x, y - 1].type == placeTileSmall || Main.tile[x + 1, y].type == placeTileSmall || Main.tile[x - 1, y].type == placeTileSmall);
                        }
                        #endregion
                    }
                }));
            }

        /*  int HouseIndex = tasks.FindIndex(genpass => genpass.Name.Equals("Floating Island Houses"));
            if (HouseIndex != -1)
            {
                tasks.Insert(HouseIndex + 1, new PassLegacy("Magnoliac Houses", delegate (GenerationProgress progress)
                {
                    progress.Message = "Magnoliac Houses";

                    
                }));
            }   */

            int WellIndex = tasks.FindIndex(genpass => genpass.Name.Equals("Larva"));
            if (WellIndex != -1)
            {
                tasks.Insert(WellIndex + 1, new PassLegacy("Digging Well", delegate (GenerationProgress progress)
                {
                    progress.Message = "Digging Well";
                    
                    float distance = Vector2.Distance(new Vector2(miner.genPos[0].X / 16, Main.spawnTileY) - new Vector2(miner.genPos[0].X, miner.genPos[1].Y) / 16, Vector2.Zero);
                    for (int i = 0; i < (int)distance; i++)
                    {
                        for (int j = -2; j < 3; j++)
                        {
                            WorldGen.KillTile((int)miner.genPos[0].X / 16 + j, Main.spawnTileY + i, false, false, true);
                            WorldGen.KillTile((int)miner.genPos[0].X / 16 + j, Main.spawnTileY + i, false, false, true);
                            if (j == -2 || j == 2)
                            {
                                WorldGen.PlaceTile((int)miner.genPos[0].X / 16 + j, Main.spawnTileY + i, TileID.RedBrick, true, true);
                            }
                        }
                        WorldGen.PlaceTile((int)miner.genPos[0].X / 16, Main.spawnTileY + i, TileID.Rope);
                    }
                }));
            }
        }

        int HouseWidth = 20;
        int HouseHeight = 8;
        int columnID = 0;
        int rowID = 0;
        int[] column;
        int[] row;
        int[,] houseShape;
        public bool PlaceHouse(int i, int j)
        {
            HouseWidth = 24 + WorldGen.genRand.Next(-6, 4);
            HouseHeight = 12 + WorldGen.genRand.Next(-2, 2);
        //  different house generation based on stored values
        //  column = new int[HouseWidth];
        //  row = new int[HouseHeight];
            houseShape = new int[HouseHeight, HouseWidth];
            for (int k = 0; k < houseShape.GetLength(0); k++)
            {
            //  different house generation based on stored values
            //  column[columnID] = k;
                houseShape[k, 0] = 1;
                houseShape[k, HouseWidth - 1] = 1;
            //  columnID++;
            }
            for (int l = 0; l < houseShape.GetLength(1); l++)
            {
            //  different house generation based on stored values
            //  row[rowID] = l;
                houseShape[0, l] = 1;
                houseShape[HouseHeight - 1, l] = 1;
                if (l > 4 && l < 9 + WorldGen.genRand.Next(-1, 2))
                {
                    houseShape[0, l] = 2;
                }
            //  rowID++;
            }
            for (int y = 0; y < houseShape.GetLength(0); y++)
            {
                for (int x = 0; x < houseShape.GetLength(1); x++)
                {
                    int m = i + x;
                    int n = j + y;
                    if (WorldGen.InWorld(m, n, 30))
                    {
                        Tile tile = Framing.GetTileSafely(m, n);
                        switch (houseShape[y, x])
                        {
                            case 0:
                                tile.type = TileID.Dirt;
                                tile.active(false);
                                tile.wall = WallID.ObsidianBrick;
                                break;
                            case 1:
                                tile.type = (ushort)mod.TileType<Tiles.m_brick>();
                                tile.active(true);
                                break;
                            case 2:
                                tile.type = TileID.Platforms;
                                tile.active(true);
                                break;
                        }
                    }
                    WorldGen.SquareTileFrame(m, n, true);
                    WorldGen.SquareWallFrame(m, n, true);
                }
            }   
            return true;
        }

        private bool Gemmable(int type)
        {
            return type == 0 || type == 1 || type == 40 || type == 59 || type == 60 || type == 70 || type == 147 || type == 161 || type == miner.mod.TileType<Tiles.m_stone>(); 
        }
        
        public static void DrawChain(Vector2 start, Vector2 end, Texture2D texture, SpriteBatch spriteBatch)
        {
            start -= Main.screenPosition;
            end -= Main.screenPosition;

            int linklength = texture.Height;
            Vector2 chain = end - start;

            float length = (float)chain.Length();
            int numlinks = (int)Math.Ceiling(length / linklength);
            Vector2[] links = new Vector2[numlinks];
            float rotation = (float)Math.Atan2(chain.Y, chain.X);

            for (int i = 0; i < numlinks; i++)
            {
                links[i] = start + chain / numlinks * i;
            }

            for (int i = 0; i < numlinks; i++)
            {
                Color color = Lighting.GetColor((int)((links[i].X + Main.screenPosition.X) / 16), (int)((links[i].Y + Main.screenPosition.Y) / 16));
                spriteBatch.Draw(texture,
                new Rectangle((int)links[i].X, (int)links[i].Y, texture.Width, linklength), null,
                color, rotation + 1.57f, new Vector2(texture.Width / 2f, linklength), SpriteEffects.None, 1f);
            }
        }
    }
    public class Miner : ModWorld
    {
        public Mod mod = ModLoader.GetMod("TestEnvironment");
        public static string progressText = "";
        static int numMiners = 0, randomX, randomY, bottomBounds = Main.maxTilesY, rightBounds = Main.maxTilesX, circumference, ticks;
        public int edge = 128;
        float mineBlockX = 256, mineBlockY = 256;
        float RightBounds;
        static bool runner = false, grassRunner = false, fillerRunner = false, russianRoulette = false;
        public Vector2 center = new Vector2((Main.maxTilesX / 2) * 16, (Main.maxTilesY / 2) * 16);
        public int buffer = 1, offset = 200;
        int whoAmI = 0, type = 0;
        int XOffset = 512, YOffset = 384;
        public int jobCount = 0;
        public int jobCountMax = 32;
        static int moveID, lookFurther, size = 1;
        public Vector2 minerPos;
        public Vector2 finalVector;
        static Vector2 oldMinerPos, deadZone = Vector2.Zero;
        Vector2 position;
        Vector2 mineBlock;
        bool init = false;
        bool fail;
        bool switchMode = false;
        public Vector2[] genPos = new Vector2[2];
        Vector2[] minePath = new Vector2[800*800];
    //  for loop takes care of need to generate new miners
    //  Miner[] ID = new Miner[400];
        public void Init()
        {
            if (whoAmI == 0)
            {
            //  remove comments for next version
            /*  float offset = XOffset * WorldGen.genRand.Next(-1, 1);
                if(offset == 0)
                {
                    offset = XOffset;
                }   */
                minerPos = center + new Vector2(0 /*offset * 16f*/, Main.maxTilesY - YOffset);
            }
            else
            {
                int RandomX = WorldGen.genRand.Next(-2, 2);
                int RandomY = WorldGen.genRand.Next(-2, 2);
                if (RandomX != 0 && RandomY != 0)
                {
                    mineBlock = new Vector2(mineBlockX * RandomX, mineBlockY * RandomY);
                    minerPos += mineBlock;
                }
                else
                {
                    mineBlock = new Vector2(mineBlockX, mineBlockY);
                    minerPos += mineBlock;
                    return;
                }
            }
            minePath[0] = center;
            init = true;
        //  Main.spawnTileX = (int)center.X / 16;
        //  Main.spawnTileY = (int)center.Y / 16;
            progressText = jobCount + " initiated, " + Math.Round((double)((float)jobCount / jobCountMax) * 10, 0) + "%";
        }
        public void Update()
        {
            if (!init) Init();
            if (init && whoAmI == 0)
            {
                for (int k = 0; whoAmI < 800; k++)
                {
                    Mine();
                }
            }
            else if (whoAmI > 0 && whoAmI <= 800)
            {
                for (int k = 0; whoAmI < 800; k++)
                {
                    Mine();
                }
                if (whoAmI == 800)
                {
                    jobCount++;
                    Init();
                    whoAmI = 1;
                }
            }

            if (minerPos.X < center.X) 
                center.X = minerPos.X;
            if (minerPos.Y < center.Y)
                center.Y = minerPos.Y;
            if (minerPos.X > oldMinerPos.X)
                oldMinerPos.X = minerPos.X;
            if (minerPos.Y > oldMinerPos.Y)
                oldMinerPos.Y = minerPos.Y;

            if (jobCount > jobCountMax)
            {
                progressText = "Process complete";
                int layer = (int)Main.worldSurface;
                int offset = Main.maxTilesY / 2;
                if (minerPos.X < center.X)
                {
                    genPos[0] = new Vector2(minerPos.X, center.Y);
                    genPos[1] = oldMinerPos;
                }
                if(minerPos.X > center.X)
                {
                    genPos[0] = center;
                    genPos[1] = oldMinerPos;
                }
                if (!switchMode)
                {
                    switchMode = true;
                    Dig();
                }
            }
            if (switchMode)
            {
            //  jobCount--;
            //  Reset();
                Terminate();
            }
        }
        public void AverageMove() // most average path, sometimes most interesting
        {
            size = Main.rand.Next(1, 3);
            if (Main.rand.Next(4) == 1)
            {
                minerPos.X += 16;
                Dig();
            }
            if (Main.rand.Next(4) == 1)
            {
                minerPos.X -= 16;
                Dig();
            }
            if (Main.rand.Next(4) == 1)
            {
                minerPos.Y += 16;
                Dig();
            }
            if (Main.rand.Next(4) == 1)
            {
                minerPos.Y -= 16;
                Dig();
            }
            GenerateNewMiner();
        }
        public void DirectionalMove() // tends to stick to a path
        {
            size = Main.rand.Next(1, 3);
            if (Main.rand.Next(4) == 1 && Main.tile[(int)(minerPos.X + 16 + (16 * lookFurther)) / 16, (int)minerPos.Y / 16].active())
            {
                minerPos.X += 16;
                Dig();
            }
            if (Main.rand.Next(4) == 1 && Main.tile[(int)(minerPos.X - 16 - (16 * lookFurther)) / 16, (int)minerPos.Y / 16].active())
            {
                minerPos.X -= 16;
                Dig();
            }
            if (Main.rand.Next(4) == 1 && Main.tile[(int)minerPos.X / 16, (int)(minerPos.Y + 16 + (16 * lookFurther)) / 16].active())
            {
                minerPos.Y += 16;
                Dig();
            }
            if (Main.rand.Next(4) == 1 && Main.tile[(int)minerPos.X / 16, (int)(minerPos.Y - 16 - (16 * lookFurther)) / 16].active())
            {
                minerPos.Y -= 16;
                Dig();
            }
            if (!Main.tile[(int)(minerPos.X + 16 + (16 * lookFurther)) / 16, (int)minerPos.Y / 16].active() &&
                !Main.tile[(int)(minerPos.X - 16 - (16 * lookFurther)) / 16, (int)minerPos.Y / 16].active() &&
                !Main.tile[(int)minerPos.X / 16, (int)(minerPos.Y + 16 + (16 * lookFurther)) / 16].active() &&
                !Main.tile[(int)minerPos.X / 16, (int)(minerPos.Y - 16 - (16 * lookFurther)) / 16].active())
            {
                lookFurther++;
                if (lookFurther % 2 == 0) progressText = "Looking " + lookFurther + " tiles further";
                PlaceWater();
            }
            else lookFurther = 0;
            GenerateNewMiner();
        }
        public void ToTheSurfaceMove() // it likes randomizer = 3
        {
            moveID = 0;
            if (Main.tile[(int)(minerPos.X + 16 + (16 * lookFurther)) / 16, (int)minerPos.Y / 16].active())
            {
                moveID++;
            }
            if (Main.tile[(int)(minerPos.X - 16 - (16 * lookFurther)) / 16, (int)minerPos.Y / 16].active())
            {
                moveID++;
            }
            if (Main.tile[(int)minerPos.X / 16, (int)(minerPos.Y + 16 + (16 * lookFurther)) / 16].active())
            {
                moveID++;
            }
            if (Main.tile[(int)minerPos.X / 16, (int)(minerPos.Y - 16 - (16 * lookFurther)) / 16].active())
            {
                moveID++;
            }
            int randomizer = Main.rand.Next(0, moveID);
            size = Main.rand.Next(1, 3);
            if (randomizer == 0)
            {
                lookFurther++;
                int adjust = Main.rand.Next(1, 4);
                if (adjust == 1)
                {
                    minerPos.X -= 16;
                    PlaceWater();
                    Dig();
                }
                else if (adjust == 2)
                {
                    minerPos.X += 16;
                    PlaceWater();
                    Dig();
                }
                else if (adjust == 3)
                {
                    minerPos.Y -= 16;
                    PlaceWater();
                    Dig();
                }
                else if (adjust == 4)
                {
                    minerPos.Y += 16;
                    PlaceWater();
                    Dig();
                }
                return;
            }
            if (randomizer == 1)
            {
                minerPos.X -= 16;
                Dig();
            }
            if (randomizer == 2)
            {
                minerPos.Y -= 16;
                Dig();
            }
            if (randomizer == 3)
            {
                minerPos.Y += 16;
                Dig();
            }
            if (randomizer == 4)
            {
                minerPos.X += 16;
                Dig();
            }
            GenerateNewMiner();
            lookFurther = 0;
        }
        public void StiltedMove()    // stilted, might work if more iterations of movement, sometimes longest tunnel
        {                                   // best water placer, there's another move that could be extracted from this if the ID segments were removed
            moveID = 0;
            if (Main.tileSolid[Main.tile[(int)(minerPos.X + 16 + (16 * lookFurther)) / 16, (int)minerPos.Y / 16].type])
            {
                moveID++;
            }
            if (Main.tileSolid[Main.tile[(int)(minerPos.X - 16 - (16 * lookFurther)) / 16, (int)minerPos.Y / 16].type])
            {
                moveID++;
            }
            if (Main.tileSolid[Main.tile[(int)minerPos.X / 16, (int)(minerPos.Y + 16 + (16 * lookFurther)) / 16].type])
            {
                moveID++;
            }
            if (Main.tileSolid[Main.tile[(int)minerPos.X / 16, (int)(minerPos.Y - 16 - (16 * lookFurther)) / 16].type])
            {
                moveID++;
            }
            int randomizer = Main.rand.Next(0, moveID);
            size = Main.rand.Next(1, 3);
            if (randomizer == 0)
            {
                lookFurther++;
                int adjust = Main.rand.Next(1, 4);
                if (adjust == 1)
                {
                    minerPos.X -= 16 * 2;
                    PlaceWater();
                }
                else if (adjust == 2)
                {
                    minerPos.X += 16 * 2;
                    PlaceWater();
                }
                else if (adjust == 3)
                {
                    minerPos.Y -= 16 * 2;
                    PlaceWater();
                }
                else if (adjust == 4)
                {
                    minerPos.Y += 16 * 2;
                    PlaceWater();
                }
                return;
            }
            if (randomizer == 1 && Main.rand.Next(6) == 2)
            {
                minerPos.X -= 16;
                Dig();
            }
            if (randomizer == 2 && Main.rand.Next(10) == 4)
            {
                minerPos.Y -= 16;
                Dig();
            }
            if (randomizer == 3)
            {
                minerPos.Y += 16;
                Dig();
            }
            if (randomizer == 4 && Main.rand.Next(5) == 4)
            {
                minerPos.X += 16;
                Dig();
            }
            GenerateNewMiner();
            lookFurther = 0;
        }
        public void GenerateNewMiner()
        {
            int randomizer = Main.rand.Next(0, 100);
            if (randomizer < 20 && whoAmI < 800)
            {
            //  Codable.RunGlobalMethod("ModWorld", "miner.Init", new object[] { 0 });
            //  progressText = "Miner " + whoAmI + " created";
                whoAmI++;
            
            //  unecessary, jobCount takes care of new mining tasks
                //  miner.whoAmI = whoAmI;
            /*  int newMiner = NewMiner(minerPos.X, minerPos.Y, 0, whoAmI);
                ID[newMiner].init = false;
                ID[newMiner].Dig(); */
            //  miner.ID[newID].minerPos = Miner.minerPos;
            }
        }
        public void Dig()
        {
            if (type < 800 * 800)
            {
                type++;
                minePath[type] = minerPos;
            }

            if (!switchMode)
            {
                for (int k = 2; k < 24; k++)
                {
                    WorldGen.PlaceTile((int)(minerPos.X / 16) + k, (int)(minerPos.Y / 16) + k, mod.TileType<Tiles.m_stone>(), true, true);
                    WorldGen.PlaceTile((int)(minerPos.X / 16) - k, (int)(minerPos.Y / 16) - k, mod.TileType<Tiles.m_stone>(), true, true);
                    WorldGen.PlaceTile((int)(minerPos.X / 16) + k, (int)(minerPos.Y / 16) - k, mod.TileType<Tiles.m_stone>(), true, true);
                    WorldGen.PlaceTile((int)(minerPos.X / 16) - k, (int)(minerPos.Y / 16) + k, mod.TileType<Tiles.m_stone>(), true, true);
                    WorldGen.KillWall((int)minerPos.X / 16 + k, (int)minerPos.Y / 16 + k, false);
                    WorldGen.KillWall((int)minerPos.X / 16 - k, (int)minerPos.Y / 16 - k, false);
                    WorldGen.KillWall((int)minerPos.X / 16 + k, (int)minerPos.Y / 16 - k, false);
                    WorldGen.KillWall((int)minerPos.X / 16 - k, (int)minerPos.Y / 16 + k, false);
                }
            }
            if (switchMode)
            {
                for (int k = 0; k < type; k++)
                {
                    minerPos = minePath[k];
                    if (WorldGen.genRand.Next(60) == 0) PlaceWater();
                    if (size == 1)
                    {
                        WorldGen.KillTile((int)(minerPos.X / 16) + circumference, (int)(minerPos.Y / 16) + circumference, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + circumference, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) + circumference, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + 1, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) - 1, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) + 1, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) - 1, false, false, true);
                    }
                    else if (size == 2)
                    {
                        WorldGen.KillTile((int)(minerPos.X / 16) + circumference, (int)(minerPos.Y / 16) + circumference, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + circumference, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) + circumference, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + circumference * 2, (int)(minerPos.Y / 16) + circumference * 2, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + circumference * 2, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) + circumference * 2, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + 1, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) - 1, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) + 1, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) - 1, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + 1, (int)(minerPos.Y / 16) + 1, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) - 1, (int)(minerPos.Y / 16) - 1, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + 1, (int)(minerPos.Y / 16) - 1, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) - 1, (int)(minerPos.Y / 16) + 1, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + 2, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) - 2, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) + 2, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) - 2, false, false, true);
                    }
                    else if (size == 3)
                    {
                        WorldGen.KillTile((int)(minerPos.X / 16) + circumference, (int)(minerPos.Y / 16) + circumference, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + circumference, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) + circumference, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + circumference * 2, (int)(minerPos.Y / 16) + circumference * 2, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + circumference * 2, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) + circumference * 2, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + circumference * 3, (int)(minerPos.Y / 16) + circumference * 3, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + circumference * 3, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) + circumference * 3, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + 1, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) - 1, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) + 1, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) - 1, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + 1, (int)(minerPos.Y / 16) + 1, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) - 1, (int)(minerPos.Y / 16) - 1, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + 1, (int)(minerPos.Y / 16) - 1, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) - 1, (int)(minerPos.Y / 16) + 1, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + 2, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) - 2, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) + 2, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) - 2, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + 2, (int)(minerPos.Y / 16) + 2, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) - 2, (int)(minerPos.Y / 16) - 2, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + 2, (int)(minerPos.Y / 16) - 2, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) - 2, (int)(minerPos.Y / 16) + 2, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) + 3, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16) - 3, (int)(minerPos.Y / 16), false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) + 3, false, false, true);
                        WorldGen.KillTile((int)(minerPos.X / 16), (int)(minerPos.Y / 16) - 3, false, false, true);
                    }
                }
            }
        }
        public void PlaceWater()
        {
            int randomizer = Main.rand.Next(0, 100);
            if (randomizer < 8)
            { // old randomizer%12 == 0
                Main.tile[(int)(minerPos.X / 16) + circumference, (int)(minerPos.Y / 16)].liquid = 255;
                Main.tile[(int)(minerPos.X / 16), (int)(minerPos.Y / 16) + circumference].liquid = 255;
                WorldGen.SquareTileFrame((int)(minerPos.X / 16), (int)(minerPos.Y / 16));
            }
            if (circumference != 1) return;
        }
        public void Mine()
        {
            //	AverageMove();
            DirectionalMove();
            //	ToTheSurfaceMove();
            //	StiltedMove();
            //  used only in the removal of newly generated miners
/*          if(russianRoulette){
                int life = -5;
                int death = 60;
                int roulette = Main.rand.Next(life, death);
                if(roulette == death && whoAmI > 0){
                    ID[whoAmI] = null;
                    whoAmI++;
                }
            }   */
            if (!switchMode && minerPos != Vector2.Zero && jobCount < jobCountMax/* && (minerPos.X < edge * 16 && minerPos.X > (rightBounds - edge) * 16 && minerPos.Y < edge * 16 && minerPos.Y > (bottomBounds - edge) * 16)*/)
            {
                int RandomX = WorldGen.genRand.Next(-2, 2);
                int RandomY = WorldGen.genRand.Next(-2, 2);
                if (RandomX != 0 && RandomY != 0)
                {
                    if (minerPos.Y / 16 > Main.maxTilesY / 3 && minerPos.Y < bottomBounds - edge)
                    {
                        mineBlock = new Vector2(mineBlockX * RandomX, mineBlockY * RandomY);
                        minerPos += mineBlock;
                    }
                    if (minerPos.Y / 16 < Main.maxTilesY / 3)
                    {
                        minerPos.Y += mineBlockY;
                    }
                    if (minerPos.Y /16 > bottomBounds - edge)
                    {
                        minerPos.Y -= mineBlockY;
                    }
                }
                else return;
            }
        }
        public void Randomizer()
        {
            randomX = Main.rand.Next(edge, rightBounds - edge);
            randomY = Main.rand.Next((int)Main.rockLayer, bottomBounds - edge);
            for (int j = -1; j < 1; j++)
            {
                circumference = j;
            }
        }
        public void Terminate()
        {
            minerPos = center;
        }
        public void Reset()
        {
            progressText = "";
            minerPos = center;
            whoAmI = 0;
            jobCount = 0;
            switchMode = false;
            init = false;
        }
    }
}