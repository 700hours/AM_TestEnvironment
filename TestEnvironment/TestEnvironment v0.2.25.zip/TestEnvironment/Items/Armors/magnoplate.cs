﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using TestEnvironment.Projectiles;

namespace TestEnvironment.Items.Armors
{
    [AutoloadEquip(EquipType.Body)]
    public class magnoplate : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Magno Breastplate");
            //  need to update tooltip with full set
            Tooltip.SetDefault("Generates protective shield"
                    +   "\nEach shield can take four hits");
        }
        public override void SetDefaults()
        {
            item.width = 18;
            item.height = 18;
            item.maxStack = 1;
            item.value = 100;
            item.rare = 2;
            item.defense = 5;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(9);
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }

        bool shield = false;
        int Proj;
        int ticks = 180;
        float radius = 96f;
        float degrees = 67.5f;
        const float radians = 0.017f;
        Vector2 playerCenter;
        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return head.type == mod.ItemType("magnohelmet") && legs.type == mod.ItemType("magnogreaves");
        }
        public override void UpdateArmorSet(Player player)
        {
/*          TestPlayer modPlayer = player.GetModPlayer<TestPlayer>(mod);

            playerCenter = new Vector2(player.position.X + player.width / 2, player.position.Y + player.height / 2);
            if (!shield)
            {
                for(int k = 0; k < 4; k++)
                {
                    float ProjX = playerCenter.X + (float)(radius * Math.Cos(degrees * k));
                    float ProjY = playerCenter.Y + (float)(radius * Math.Sin(degrees * k));
                    Proj = Projectile.NewProjectile(new Vector2(ProjX, ProjY), Vector2.Zero, mod.ProjectileType<m_shield>(), 0, 0f, player.whoAmI, degrees * k, 0f);
                }
                Main.PlaySound(mod.GetLegacySoundSlot(SoundType.Custom, "/Sounds/Custom/conjure"), player.Center);
                shield = true;
            }
            if (player.ownedProjectileCounts[mod.ProjectileType<m_shield>()] <= 2)
            {
                ticks--;
                if (ticks == 0)
                {
                    modPlayer.magnoShield = false;
                    shield = false;
                    ticks = 180;
                }
            }
            else modPlayer.magnoShield = true;  */
        } 
    }
}
