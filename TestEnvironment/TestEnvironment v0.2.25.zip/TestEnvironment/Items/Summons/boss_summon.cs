﻿using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using TestEnvironment.NPCs;

namespace TestEnvironment.Items.Summons
{
    public class boss_summon : ModItem
    {
        public override void SetStaticDefaults()
        {
        //  DisplayName.SetDefault("Test Summoner");
        //  Tooltip.SetDefault("Reminiscent of something...");
        }
        public override void SetDefaults()
        {
            item.width = 20;
            item.height = 20;
            item.useTime = 45;
            item.useAnimation = 45;
            item.useStyle = 4;
            item.value = 100;
            item.rare = 2;
            item.autoReuse = false;
            item.consumable = false;
            item.noMelee = true;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(9);
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }

        bool flag = false;
        int spawn;
        public override bool UseItem(Player player)
        {
            int npcWidth = 100;
            int npcHeight = 93;
            float npcX = player.position.X - 8 + (player.width - npcWidth) * 0.5f;
            float npcY = player.position.Y - npcHeight + 40;
            spawn = NPC.NewNPC((int)npcX - 180, (int)npcY, mod.NPCType("boss_magnohead"));
            
            
        /*  if (Main.netMode == 1)
            {
                ModPacket packet = mod.GetPacket();
                packet.Write(spawn);
                packet.Write(Main.npc[spawn].whoAmI);
                packet.Send();
            }   */
            if (Main.netMode == 1)
                NetMessage.SendData(23, -1, -1, null, spawn, 0f, 0f, 0f, 0, 0, 0);
            return true;
        }
    }
}
