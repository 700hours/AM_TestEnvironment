﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment.Items
{
    public class cinnabar_hamaxe : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Cinnabar Hamaxe");
        }
        public override void SetDefaults()
        {
            item.width = 48;
            item.height = 48;
            item.scale = 1f;
            item.useTime = 20;
            item.useAnimation = 20;
            item.useStyle = 1;
            //  item % power
            item.axe = 20;
            item.hammer = 50;
            item.damage = 18;
            item.knockBack = 7.5f;
            item.value = 1500;
            item.rare = 2;
            //  custom sound?
            //  item.UseSound = mod.GetLegacySoundSlot(SoundType.Item, "Sounds/Item/*");
            //  or vanilla sound?
            item.UseSound = SoundID.Item1;
            item.autoReuse = true;
            item.melee = true;
        }
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(9);
            recipe.SetResult(this, 1);
            recipe.AddRecipe();
        }
    }
}
