﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment.NPCs
{
    public class boss_magnobody : ModNPC
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Magnoliac Entity");
        }
        public override void SetDefaults()
        {
            npc.width = 74;
            npc.height = 62;
            npc.friendly = false;
            npc.aiStyle = 6;
            //aiType = NPCID.Worm;
            npc.boss = true;
            npc.noTileCollide = true;
            npc.noGravity = true;
            npc.behindTiles = true;
            npc.damage = 18;
            npc.defense = 4;
            npc.lifeMax = 8045;
            npc.HitSound = SoundID.NPCHit1;
            npc.DeathSound = SoundID.NPCDeath1;
            npc.knockBackResist = 0f;
        }
        bool init = false;
        int bodyCore;
        NPC n;
        public void Initialize()
        {
            bodyCore = NPC.NewNPC((int)npc.position.X + npc.width / 2, (int)npc.position.Y + npc.height / 2, mod.NPCType<m_core>());
        }
        public override void AI()
        {
            if (!init)
            {
                Initialize();
                init = true;
            }
            if (!Main.npc[(int)npc.ai[1]].active || Main.npc[(int)npc.ai[1]].life <= 0)
            {
                npc.life = 0;
                npc.HitEffect(0, 10.0);
                npc.active = false;
            }
            n = Main.npc[bodyCore];
            n.rotation = npc.rotation;
            n.Center = npc.Center;
            if (n.life > 0 || n.active)
            {
                npc.dontTakeDamage = true;
            }
            else
            {
                npc.dontTakeDamage = false;
            }
        }
    }
}
