﻿using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;

namespace TestEnvironment.Tiles
{
    public class m_stone : ModTile
    {
        public override void SetDefaults()
        {
            Main.tileSolid[Type] = true;
            //  connects with dirt
            Main.tileMergeDirt[Type] = true;
            Main.tileBlockLight[Type] = true;
            Main.tileLighted[Type] = false;
            drop = mod.ItemType("magno_stone");
            //  UI map tile color
            AddMapEntry(new Color(119, 111, 98));
        }
    }
}
