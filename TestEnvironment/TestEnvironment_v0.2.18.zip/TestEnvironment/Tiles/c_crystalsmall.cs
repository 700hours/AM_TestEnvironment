﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using Terraria;
using Terraria.DataStructures;
using Terraria.Enums;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace TestEnvironment.Tiles
{
    public class c_crystalsmall : ModTile
    {
        public override void SetDefaults()
        {
            Main.tileFrameImportant[Type] = true;
            Main.tileLavaDeath[Type] = false;
            Main.tileSolid[Type] = false;
            Main.tileMergeDirt[Type] = false;
            Main.tileLighted[Type] = true;
            Main.tileBlockLight[Type] = false;
            Main.tileNoSunLight[Type] = false;
            Main.tileNoAttach[Type] = true;
            TileObjectData.newTile.AnchorInvalidTiles = new int[] { 127 };
            TileObjectData.newTile.StyleHorizontal = true;
            TileObjectData.newTile.LavaDeath = false;
            TileObjectData.addTile(Type);
            ModTranslation name = CreateMapEntryName();
            name.SetDefault("Cinnabar Crystal");
            AddMapEntry(new Color(210, 110, 110), name);
            disableSmartCursor = true;
        }
        public override void ModifyLight(int i, int j, ref float r, ref float g, ref float b)
        {
            r = 0.804f;
            g = 0.361f;
            b = 0.361f;
        }
        public override void KillTile(int i, int j, ref bool fail, ref bool effectOnly, ref bool noItem)
        {
            //  drops cinnabar crystal   
        }

        float rotation;
        public override bool PreDraw(int i, int j, SpriteBatch spriteBatch)
        {
            bool tileCheckRot = false;
            if(!tileCheckRot)
            {
                if (Main.tileSolid[Main.tile[i - 1, j].type])
                    rotation = MathHelper.ToRadians(90f);
                else if (Main.tileSolid[Main.tile[i + 1, j].type])
                    rotation = MathHelper.ToRadians(270f);
                else if (Main.tileSolid[Main.tile[i, j - 1].type])
                    rotation = MathHelper.ToRadians(180f);
                else if (Main.tileSolid[Main.tile[i, j + 1].type])
                    rotation = 0f;
                tileCheckRot = true;
            }
            Main.spriteBatch.Draw(Main.tileTexture[Type], 
                new Rectangle((int)(i * 16 - Main.screenPosition.X), (int)(j * 16 - Main.screenPosition.Y), 16, 16),
                null, default(Color), rotation, default(Vector2), SpriteEffects.None, 0f);
            return false;
        }
    }
}
