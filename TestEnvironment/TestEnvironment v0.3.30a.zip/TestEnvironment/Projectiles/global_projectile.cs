﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using TestEnvironment;

namespace TestEnvironment.Projectiles
{
    public class global_projectile : GlobalProjectile
    {
        public override void PostAI(Projectile projectile)
        {
            
        }
    }
}
