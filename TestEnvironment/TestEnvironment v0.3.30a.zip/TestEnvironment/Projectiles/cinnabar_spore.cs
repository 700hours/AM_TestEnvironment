﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment.Projectiles
{
    public class cinnabar_spore : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Cinnabar Spore");
        }
        public override void SetDefaults()
        {
            projectile.width = 32;
            projectile.height = 32;
            projectile.scale = 1f;
            projectile.aiStyle = -1;
            projectile.timeLeft = 300;
            projectile.damage = 10;
            projectile.knockBack = 5f;
            projectile.penetrate = -1;
            projectile.friendly = true;
            projectile.ownerHitCheck = true;
            projectile.tileCollide = false;
            projectile.ignoreWater = true;
            projectile.magic = true;
        }

        bool spawnOK = false;
        int buffer = 256;
        int x, y;
        public void Initialize()
        {
            maxTime = projectile.timeLeft;

            Player player = Main.player[projectile.owner];

            foreach (NPC n in Main.npc)
            {
                if (!target && n.active && !n.friendly && !n.dontTakeDamage && !n.immortal && n.target == player.whoAmI && ((n.lifeMax >= 10 && !Main.expertMode) || (n.lifeMax >= 30 && (Main.expertMode || Main.hardMode))))
                {
                    npcTarget = n.whoAmI;
                    target = true;
                }
            }
            if (target && Vector2.Distance(player.position - Main.npc[npcTarget].position, Vector2.Zero) <= 512)
            {
                projectile.Center = Main.npc[npcTarget].Center;
            }
            else
            {
                x = Main.rand.Next((int)player.position.X - buffer, (int)player.position.X + buffer);
                y = Main.rand.Next((int)player.position.Y - buffer, (int)player.position.Y + buffer);
                projectile.position = new Vector2(x, y);
            }
        }
        bool init = false;
        bool target = false;
        int ticks = 0;
        int maxTime;
        int npcTarget;
        float rot = 0;
        const float radians = 0.017f;
        Vector2 npcCenter;
        public override void AI()
        {
            if (!init)
            {
                Initialize();
                init = true;
            }

            Player player = Main.player[projectile.owner];

            NPC nme = Main.npc[npcTarget];

            int direction = 0;
            if (projectile.velocity.X < 0)
                direction = -1;
            else direction = 1;
            if (projectile.Hitbox.Intersects(nme.Hitbox))
            {
                if (ticks % 60 == 0)
                {
                    nme.StrikeNPC(projectile.damage, projectile.knockBack, direction, false, false, false);
                }
            }

            rot += radians * 2f;
            projectile.rotation = rot;

            ticks++;

            if (TileCheck((int)projectile.position.X / 16, (int)projectile.position.Y / 16))
            {
                projectile.alpha = 255;
                projectile.position.X = Main.rand.Next((int)player.position.X - buffer, (int)player.position.X + buffer);
                projectile.position.Y = Main.rand.Next((int)player.position.Y - buffer, (int)player.position.Y + buffer);
            }
            else
            {
                projectile.alpha = 255 * (maxTime - ticks) / maxTime;
                Lighting.AddLight(projectile.Center, new Vector3(0.804f, 0.361f, 0.361f));
            }
        }
        public override void Kill(int timeLeft)
        {
            for (int k = 0; k < 4; k++)
            {
                int killDust = Dust.NewDust(projectile.position, projectile.width, projectile.height, 4, 0f, 0f, 0, default(Color), 1f);
            }
        }

        public bool TileCheck(int i, int j)
        {
            bool Active = Main.tile[i, j].active() == true;
            bool Solid = Main.tileSolid[Main.tile[i, j].type] == true;

            if (Solid && Active) return true;
            else return false;
        }
    }
}
