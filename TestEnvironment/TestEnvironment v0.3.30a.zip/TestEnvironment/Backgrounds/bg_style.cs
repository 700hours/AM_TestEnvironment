﻿using Terraria;
using Terraria.ModLoader;

namespace TestEnvironment.Backgrounds
{
    public class BackgroundStyle : ModUgBgStyle
    {
        public override bool ChooseBgStyle()
        {
            return Main.LocalPlayer.GetModPlayer<TestPlayer>(mod).MagnoZone;
        }

        public override void FillTextureArray(int[] textureSlots)
        {
            textureSlots[0] = mod.GetBackgroundSlot("Backgrounds/bg_magno");
            textureSlots[1] = mod.GetBackgroundSlot("Backgrounds/bg_magno");
            textureSlots[2] = mod.GetBackgroundSlot("Backgrounds/bg_magno");
            textureSlots[3] = mod.GetBackgroundSlot("Backgrounds/bg_magno");
        }   
    }   
} 