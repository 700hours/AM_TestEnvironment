﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using Terraria;
using Terraria.DataStructures;
using Terraria.Enums;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace TestEnvironment.Tiles
{
    public class global_tile : GlobalTile
    {
        public override void RandomUpdate(int i, int j, int type)
        {
            Tile tile = Main.tile[i, j - 1];
            if(type == mod.TileType<m_stone>())
            {
                if (!Main.tileSolid[Main.tile[i - 1, j].type])
                    WorldGen.PlaceTile(i - 1, j, mod.TileType<c_crystalwall>(), true, false);
                if (!Main.tileSolid[Main.tile[i + 1, j].type])
                    WorldGen.PlaceTile(i + 1, j, mod.TileType<c_crystalwall>(), true, false);
                if (!Main.tileSolid[tile.type] && !tile.active())
                {
                    int chance = Main.rand.Next(4);
                    switch (chance)
                    {
                        case 0:
                            WorldGen.PlaceTile(i, j - 1, mod.TileType<c_crystal2x2>(), true, false);
                            break;
                        case 1:
                            WorldGen.PlaceTile(i, j - 1, mod.TileType<c_crystal2x1>(), true, false);
                            break;
                    }
                }
            }
        }
        public override bool Slope(int i, int j, int type)
        {
            if (Main.tile[i, j - 1].type == mod.TileType<c_crystalsmall>() ||
                Main.tile[i, j - 1].type == mod.TileType<c_crystal2x1>() ||
                Main.tile[i, j - 1].type == mod.TileType<c_crystal2x2>() ||
                Main.tile[i + 1, j].type == mod.TileType<c_crystalwall>() ||
                Main.tile[i - 1, j].type == mod.TileType<c_crystalwall>())
            {
                return false;
            }
            else return true;
        }
        public override bool CanKillTile(int i, int j, int type, ref bool blockDamaged)
        {
            if (Main.tile[i, j - 1].type == mod.TileType<c_crystalsmall>() ||
                Main.tile[i, j - 1].type == mod.TileType<c_crystal2x1>() ||
                Main.tile[i, j - 1].type == mod.TileType<c_crystal2x2>() ||
                Main.tile[i + 1, j].type == mod.TileType<c_crystalwall>() ||
                Main.tile[i - 1, j].type == mod.TileType<c_crystalwall>())
            {
                return false;
            }
            else return true;
        }
        public override void KillTile(int i, int j, int type, ref bool fail, ref bool effectOnly, ref bool noItem)
        {
            TestPlayer modPlayer = Main.LocalPlayer.GetModPlayer<TestPlayer>(mod);
            
            if (Main.tile[i, j].type == TileID.Books && Main.tile[i, j].frameX == 90 && modPlayer.MagnoZone)
            {
                noItem = true;
                Item.NewItem(new Vector2(i * 16, j * 16), mod.ItemType("magno_book"), 1, false, -1, true, false);
            }
        }
    }
}
