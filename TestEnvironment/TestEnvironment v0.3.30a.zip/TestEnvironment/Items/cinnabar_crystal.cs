﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment.Items
{
    public class cinnabar_crystal : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Cinnabar Crystal");
            Tooltip.SetDefault("Glows with a crimson aura");
        }
        public override void SetDefaults()
        {
            item.width = 32;
            item.height = 32;
            item.scale = 1f;
            item.value = 1000;
            item.maxStack = 99;
            item.rare = 2;
        }
        public override void AddRecipes()
        {
            ModRecipe recipeT = new ModRecipe(mod);
            recipeT.AddIngredient(9);
            recipeT.SetResult(this, 1);
            recipeT.AddRecipe();
        }
    }
}
