﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment.Projectiles
{
    public class global_projectile : GlobalProjectile
    {
        public override void AI(Projectile projectile)
        {
            Player player = Main.player[projectile.owner];
            TestPlayer modPlayer = player.GetModPlayer<TestPlayer>(mod);

            if (projectile.owner == player.whoAmI && modPlayer.magnoRanged && projectile.type == ProjectileID.WoodenArrowFriendly)
            {
                projectile.type = ProjectileID.UnholyArrow;
            }
        }
    }
}
