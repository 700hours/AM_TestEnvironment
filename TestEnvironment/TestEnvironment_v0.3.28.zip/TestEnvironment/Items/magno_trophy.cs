﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment.Items
{
    public class magno_trophy : ModItem
    {
    }
}
