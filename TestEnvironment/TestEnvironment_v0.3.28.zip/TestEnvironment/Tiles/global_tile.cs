﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using Terraria;
using Terraria.DataStructures;
using Terraria.Enums;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace TestEnvironment.Tiles
{
    public class global_tile : GlobalTile
    {
        public override bool Slope(int i, int j, int type)
        {
            if (Main.tile[i, j - 1].type == mod.TileType<c_crystalsmall>() ||
                Main.tile[i, j - 1].type == mod.TileType<c_crystal2x1>() ||
                Main.tile[i, j - 1].type == mod.TileType<c_crystal2x2>() ||
                Main.tile[i + 1, j].type == mod.TileType<c_crystalwall>() ||
                Main.tile[i - 1, j].type == mod.TileType<c_crystalwall>())
            {
                return false;
            }
            else return true;
        }
        public override bool CanKillTile(int i, int j, int type, ref bool blockDamaged)
        {
            if (Main.tile[i, j - 1].type == mod.TileType<c_crystalsmall>() ||
                Main.tile[i, j - 1].type == mod.TileType<c_crystal2x1>() ||
                Main.tile[i, j - 1].type == mod.TileType<c_crystal2x2>() ||
                Main.tile[i + 1, j].type == mod.TileType<c_crystalwall>() ||
                Main.tile[i - 1, j].type == mod.TileType<c_crystalwall>())
            {
                return false;
            }
            else return true;
        }
    }
}
