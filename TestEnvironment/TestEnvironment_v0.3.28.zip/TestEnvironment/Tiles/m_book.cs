﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using Terraria;
using Terraria.DataStructures;
using Terraria.Enums;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace TestEnvironment.Tiles
{
    public class m_book : ModTile
    {
        public override void SetDefaults()
        {
            Main.tileSolid[Type] = false;
            //  connects with dirt
            Main.tileMergeDirt[Type] = false;
            Main.tileBlockLight[Type] = true;
            Main.tileLighted[Type] = false;
            //  for spelunker potions
            //  dustType = 1;
            //  drop = mod.ItemType("cinnabar_ore");
            //  UI map tile color
            ModTranslation name = CreateMapEntryName();
            name.SetDefault("Magno Book");
            AddMapEntry(new Color(115, 152, 201), name);
        }

        bool tileCheckFlip = false;
        int x, y;
        float rotation;
        Texture2D texture;
        public override bool PreDraw(int i, int j, SpriteBatch spriteBatch)
        {
            #region psudo update

            mineResist = 1f;
            minPick = 35;

            #endregion

            Vector2 zero = new Vector2(Main.offScreenRange, Main.offScreenRange);
            if (Main.drawToScreen)
            {
                zero = Vector2.Zero;
            }

            Main.spriteBatch.Draw(Main.tileTexture[Type],
                new Vector2(i * 16 - (int)Main.screenPosition.X, j * 16 - (int)Main.screenPosition.Y) + zero,
                new Rectangle(0, 0, 16, 16),
                Lighting.GetColor(i, j), 0f, default(Vector2), 1f, SpriteEffects.None, 0f);
            return false;
        }
    }
}
