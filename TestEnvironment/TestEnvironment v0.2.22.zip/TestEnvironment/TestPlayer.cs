using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using Terraria.GameInput;

namespace TestEnvironment
{
    public class TestPlayer : ModPlayer
    {
        public bool magnoMinion;
        public bool magnoShield;
        public bool MagnoZone = false;
        public int MPID = 0;
        int ticks = 1;
        public override void PostUpdate()
        {
            MPID = player.whoAmI;

            if (player.armor[0].type != mod.ItemType("magnohelmet") || player.armor[1].type != mod.ItemType("magnoplate") || player.armor[2].type != mod.ItemType("magnogreaves"))
            {
                magnoShield = false;
            }
            if (Main.netMode == 0)
            {
                player.statLife = player.statLifeMax;

                if (Main.mouseMiddle)
                {
                    Main.dayTime = false;
                    Main.time = 12400;
                }
            }
            if (ticks == 0 && player.whoAmI == Main.myPlayer)
            {
                int head = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), 151, 1, true, -1, true, false);
                int body = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), 152, 1, true, -1, true, false);
                int legs = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), 153, 1, true, -1, true, false);
                int weapon = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), 98, 1, true, -1, true, false);
                int ammoBullets = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), 3104, 1, true, -1, true, false);
                int ammoArrows = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.EndlessQuiver, 1, true, -1, true, false);
                int shield = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.CobaltShield, 1, true, -1, true, false);
                int dummy = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.TargetDummy, 1, true, -1, true, false);
                int dpsMeter = Item.NewItem(new Rectangle((int)player.position.X, (int)player.position.Y, 0, 0), ItemID.DPSMeter, 1, true, -1, true, false);
                ticks = 1;
            }
        }

        public override void UpdateBiomes()
        {
            MagnoZone = TestWorld.magnoTiles > 100;
        }
        public override bool CustomBiomesMatch(Player other)
        {
            TestPlayer modPlayer = other.GetModPlayer<TestPlayer>(mod);
            return MagnoZone = modPlayer.MagnoZone;
        }
        public override void CopyCustomBiomesTo(Player other)
        {
            TestPlayer modPlayer = other.GetModPlayer<TestPlayer>(mod);
            modPlayer.MagnoZone = MagnoZone;
        }
        public override void SendCustomBiomes(BinaryWriter writer)
        {
            BitsByte flags = new BitsByte();
            flags[0] = MagnoZone;
            writer.Write(flags);
        }
        public override void ReceiveCustomBiomes(BinaryReader reader)
        {
            BitsByte flags = reader.ReadByte();
            MagnoZone = flags[0];
        }
        public override Texture2D GetMapBackgroundImage()
        {
            if (MagnoZone)
            {
                return mod.GetTexture("Backgrounds/bg_magno");
            }
            return null;
        }
    }
}