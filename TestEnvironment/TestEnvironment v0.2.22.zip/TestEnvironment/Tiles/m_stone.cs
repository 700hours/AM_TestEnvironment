﻿using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;
using Microsoft.Xna.Framework.Graphics;

namespace TestEnvironment.Tiles
{
    public class m_stone : ModTile
    {
        public override void SetDefaults()
        {
            Main.tileSolid[Type] = true;
            //  connects with dirt
            Main.tileMergeDirt[Type] = true;
            Main.tileBlockLight[Type] = true;
            Main.tileLighted[Type] = false;
            drop = mod.ItemType("magno_stone");
            //  UI map tile color
            AddMapEntry(new Color(119, 111, 98));
        }
        public override bool PreDraw(int i, int j, SpriteBatch spriteBatch)
        {
            #region psudo update

            mineResist = 3f;
            minPick = 80;

            #endregion
            return true;
        }
    }
}
