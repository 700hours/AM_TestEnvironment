﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using Terraria;
using Terraria.DataStructures;
using Terraria.Enums;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace TestEnvironment.Tiles
{
    public class c_crystal2x1 : ModTile
    {
        public override void SetDefaults()
        {
            Main.tileContainer[Type] = true;
            Main.tileFrameImportant[Type] = true;
            Main.tileLavaDeath[Type] = false;
            Main.tileSolid[Type] = false;
            Main.tileMergeDirt[Type] = false;
            Main.tileLighted[Type] = true;
            Main.tileBlockLight[Type] = false;
            Main.tileNoSunLight[Type] = false;
            Main.tileNoAttach[Type] = true;
            TileObjectData.newTile.CopyFrom(TileObjectData.Style2x1);
            TileObjectData.newTile.Origin = new Point16(0, 1);
            TileObjectData.newTile.CoordinateHeights = new int[] { 16, 16 };
            TileObjectData.newTile.HookCheck = new PlacementHook(new Func<int, int, int, int, int, int>(Chest.FindEmptyChest), -1, 0, true);
            TileObjectData.newTile.HookPostPlaceMyPlayer = new PlacementHook(new Func<int, int, int, int, int, int>(Chest.AfterPlacement_Hook), -1, 0, false);
            TileObjectData.newTile.AnchorInvalidTiles = new int[] { 127 };
            TileObjectData.newTile.StyleHorizontal = true;
            TileObjectData.newTile.LavaDeath = false;
            TileObjectData.newTile.AnchorBottom = new AnchorData(AnchorType.SolidTile | AnchorType.SolidWithTop | AnchorType.SolidSide, TileObjectData.newTile.Width, 0);
            TileObjectData.addTile(Type);
            ModTranslation name = CreateMapEntryName();
            name.SetDefault("Cinnabar Crystal");
            AddMapEntry(new Color(210, 110, 110), name);
            disableSmartCursor = true;
        }
        public override void ModifyLight(int i, int j, ref float r, ref float g, ref float b)
        {
            r = 0.804f;
            g = 0.361f;
            b = 0.361f;
        }
        public override void KillMultiTile(int i, int j, int frameX, int frameY)
        {
            for (int k = 0; k < Main.rand.Next(1, 2); k++)
            {
                //  drops cinnabar crystal
            }
        }
        public override bool CanKillTile(int i, int j, ref bool blockDamaged)
        {
            TestWorld modWorld = mod.GetModWorld<TestWorld>();
            if (modWorld.MagnoDefeated)
            {
                return true;
            }
            else return false;
        }
        public override bool PreDraw(int i, int j, SpriteBatch spriteBatch)
        {
            #region psudo update

            mineResist = 2f;
            minPick = 95;

            #endregion
            return true;
        }
    }
}
