﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace TestEnvironment.Items
{
    public class magno_treasurebag : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Magno Bag");
            Tooltip.SetDefault("Right click to open");
        }
        public override void SetDefaults()
        {
            item.width = 32;
            item.height = 32;
            item.rare = 2;
        }

        public override bool CanRightClick()
        {
            return true;
        }
        public override void RightClick(Player player)
        {
            player.QuickSpawnItem(ItemID.GoldCoin, 10);
        }
        public override void Update(ref float gravity, ref float maxFallSpeed)
        {
            int i = (int)item.position.X / 16;
            int j = (int)item.position.Y / 16;

            if (Main.tileSolid[Main.tile[i, j].type])
            {
                item.position.Y--;
            }
        }
    }
}
